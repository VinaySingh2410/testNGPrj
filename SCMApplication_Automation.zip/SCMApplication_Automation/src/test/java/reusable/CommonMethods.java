package reusable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.github.mkolisnyk.cucumber.reporting.CucumberResultsOverview;
import com.github.mkolisnyk.cucumber.reporting.CucumberUsageReporting;

import dataGenerator.PropertyFileReader;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class CommonMethods {

	static WebDriver driver;
	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;
	public static String filePath = PropertyFileReader.GetValue("excelPath");
	static final Logger logger = Logger.getLogger(CommonMethods.class.getName());
	

	public static WebDriver startBrowser(String browserNames, String url)
	{PropertyConfigurator.configure("log4j.properties");

			if (browserNames.equals("firefox"))	{
				driver = new FirefoxDriver();	
				logger.info("Firefox browser has been started.");
			}
			if (browserNames.equals("chrome")){
				System.out.println("Initiallizing the browser");
				System.setProperty("webdriver.chrome.driver", PropertyFileReader.GetValue("chromeDriver"));
		        driver = new ChromeDriver();
		        logger.info("Chrome browser has been started.");
			}

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Url is:"+ url);
		driver.get(url);
		logger.info("User navigates to the url."+ url);
		return driver;

	}

	public static XSSFSheet setExcelFile(String Path,String SheetName) throws Exception {
		try {
			System.out.println(filePath);
			FileInputStream ExcelFile = new FileInputStream(filePath);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			return ExcelWSheet;
		} catch (Exception e){
			throw (e);
		}
	}
	public static String getCellData(String rowValue, String colName) throws Exception{
		try
		{
			XSSFSheet ExcelWSheet = setExcelFile(filePath,"TestResults");
			ExcelWSheet.getRow(0);
			int RowNum = getRowNum(ExcelWSheet, rowValue);
			int ColNum = getColumnNum(ExcelWSheet, colName);
            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			ExcelWBook.close();
			return CellData;
		}catch (Exception e){
			return null;
		}

	}
	public static int getRowNum(XSSFSheet excelSheet,String rowValue) throws IOException
	{
		ExcelWSheet = excelSheet;
		int rowNum = 0;
		for (int i=0;i<ExcelWSheet.getLastRowNum();i++)
		{
			XSSFRow currentRow = ExcelWSheet.getRow(i);
			System.out.println(i);
			if (currentRow!=null){
			for (int j=0;j<currentRow.getLastCellNum();j++)
			{
				Cell = ExcelWSheet.getRow(i).getCell(j);
				if (Cell!=null){
				String CellData = Cell.getStringCellValue();
				if (CellData.equalsIgnoreCase(rowValue))
					return i;
				}
			}
			}
		}
		return rowNum;
	}

	public static int getColumnNum(XSSFSheet excelSheet, String  columnName) throws IOException
	{
		ExcelWSheet = excelSheet;
		int columnNum = 0;

		int i =0;
		for (i=0;i<ExcelWSheet.getLastRowNum();i++)
		{
			XSSFRow currentRow = ExcelWSheet.getRow(i);

			for (int j=0;j<currentRow.getLastCellNum();j++)
			{
				Cell = ExcelWSheet.getRow(i).getCell(j);
				String CellData = Cell.getStringCellValue();
				if (CellData.equals(columnName))
					return j;
			}
		}
		return columnNum;
	}	
	@Test
	public void getDate() throws Exception
	{
		//    	String value = PropertyFileReader.GetValue("url_API");
		//    	System.out.println(value+"/Cart/addCartItem/format/json");
System.out.println(CommonMethods.getCellData("Buy Product A Get Product A Free", "Order Number"));
System.out.println(CommonMethods.getCellData("Buy Product A Get Product A Free", "Execution Status"));
System.out.println(CommonMethods.getCellData("Buy Product A Get Product B Free", "Order Number"));
//		CommonMethods.getCellData("239375", "deviceToken");
//		CommonMethods.getCellData("239375", "digestString");
//		CommonMethods.getCellData("239375", "timestamp");
//		CommonMethods.getCellData("239375", "deviceType");

	}


	public static void setCellData(String Result,  int RowNum, int ColNum) throws Exception	{
		try{

			FileInputStream ExcelFile = new FileInputStream(filePath);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet("Sheet1");
			Row  = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum, Row.RETURN_BLANK_AS_NULL);
			if (Cell == null) 
			{
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(Result);
			} else
				Cell.setCellValue(Result);
			FileOutputStream fileOut = new FileOutputStream(filePath);
			ExcelWBook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		}catch(Exception e){
			throw (e);
		}
	}
	public static boolean almostEqual(double a, double b, double eps){
		return Math.abs(a-b)<eps;
	}

	public static String getOfferTypeID(String offerType)
	{
		if  (offerType.equalsIgnoreCase("free SKU"))
			return "3";
		if  (offerType.equalsIgnoreCase("flat percentage"))
			return "2";

		if  (offerType.equalsIgnoreCase("flat amount"))
			return "1";

		else
			return null;

	}

	public static String getOfferID(String offerID)
	{
		if  (offerID.equalsIgnoreCase("Volume Based"))
			return "1";
		if  (offerID.equalsIgnoreCase("Value Based"))
			return "2";

		else
			return null;
	}

	public static String getDateTimeStamp() throws ParseException{
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");   
		cal.add(Calendar.YEAR, 1);
		java.util.Date date = sdf.parse(sdf.format(cal.getTime()));
		String dtval = (date.getTime()/1000L) + "";
		return dtval;
	} 
	
	public static File getCopyOfTemplateFile() throws Exception {

		// Copy a fresh Result ExcelFile from Master

		File dest = null;
		try {
			String workingDir = System.getProperty("user.dir").toString();

			System.out.println("workingDir:"+workingDir);

			String SourceFilePath = PropertyFileReader.GetValue("excelPath");
//			new File(SourceFilePath);
//			String fileName = "";
//
//			// fs = new FileInputStream(filePath);
//
//			String fileExtensionName = SourceFilePath.substring(SourceFilePath.indexOf("."));
//
//			if (fileExtensionName.equals(".xlsx"))
//				// If it is xlsx file then create object of XSSFWorkbook class
//				fileName = "testResult" + ".xlsx";
//			else if (fileExtensionName.equals(".xls"))
				// If it is xls file then create object of XSSFWorkbook class
				//fileName = "testResult" + ".xls";
			String DestFilePath = workingDir + "//"+ SourceFilePath;

			dest = new File(DestFilePath);

			//FileUtils.copyFile(source, dest);

			return dest;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dest;

	}
	public static void setValueInTestResult(TestResults testResult) throws Exception
	{
		filePath = getCopyOfTemplateFile().getAbsolutePath();
		System.out.println(filePath);
		XSSFSheet ExcelWSheet = setExcelFile(filePath,"TestResults");
		int RowNum = getRowNum(ExcelWSheet,testResult.getScenarioName());
		if (RowNum==0){
			RowNum = ExcelWSheet.getLastRowNum();
			RowNum++;
		}
		XSSFRow dataRow = ExcelWSheet.createRow(RowNum);

		int actualProductNameColumnIndex = getColumnNum(ExcelWSheet, "Actual Product Name");
		int orderNumberColumnIndex = getColumnNum(ExcelWSheet, "Order Number");
		int scenarioNameColumnIndex = getColumnNum(ExcelWSheet, "Scenario Name");
		int statusColumnIndex = getColumnNum(ExcelWSheet, "Execution Status");
		int productNameColumnIndex = getColumnNum(ExcelWSheet, "Product Names");
		int sellerNameColumnIndex = getColumnNum(ExcelWSheet, "SellerName");
		int PONameColumnIndex = getColumnNum(ExcelWSheet, "PO Name");

		dataRow.createCell(orderNumberColumnIndex).setCellValue(testResult.getOrderNumber());
		dataRow.createCell(scenarioNameColumnIndex).setCellValue(testResult.getScenarioName());
		dataRow.createCell(statusColumnIndex).setCellValue(testResult.getStatus());
		int cell =RowNum;
		
		Set<String> keys = testResult.getsellerProductMap().keySet();
		 for (String key : keys) {
	            System.out.println("Key = " + key);
	            ExcelWSheet.getRow(cell).createCell(sellerNameColumnIndex).setCellValue(key);
	            ExcelWSheet.getRow(cell).createCell(PONameColumnIndex).setCellValue(testResult.getPOMap().get(key));
	            int productRow=cell;
	            System.out.println(testResult.getsellerProductMap().get(key));
	            for (int i=0;i<testResult.getsellerProductMap().get(key).toArray().length;i++){
	            	String value = (String) testResult.getsellerProductMap().get(key).toArray()[i];
	            	ExcelWSheet.getRow(productRow).createCell(productNameColumnIndex).setCellValue(value);
	            	ExcelWSheet.getRow(productRow).createCell(actualProductNameColumnIndex).setCellValue(testResult.getProductMap().get(value));
	            	
	            	productRow++;
	            	ExcelWSheet.createRow(productRow);
	            }
	            cell = productRow;
				//ExcelWSheet.createRow(cell);
	        }
		
		
//		for (Map.Entry<String, String> entry : testResult.getProductMap().entrySet()) {
//			String key = entry.getKey();
//			String value = entry.getValue();
//			ExcelWSheet.getRow(cell).createCell(productNameColumnIndex).setCellValue(key);
//			ExcelWSheet.getRow(cell).createCell(actualProductNameColumnIndex).setCellValue(value);
//			cell++;
//			ExcelWSheet.createRow(cell);
//		}
//		ExcelWSheet.autoSizeColumn(scenarioNameColumnIndex);
//		ExcelWSheet.autoSizeColumn(orderNumberColumnIndex);
//		ExcelWSheet.autoSizeColumn(productNameColumnIndex);
//		ExcelWSheet.autoSizeColumn(actualProductNameColumnIndex);
//		ExcelWSheet.autoSizeColumn(statusColumnIndex);
//		ExcelWSheet.addMergedRegion(new CellRangeAddress(RowNum,cell-1,orderNumberColumnIndex,orderNumberColumnIndex));
//		ExcelWSheet.addMergedRegion(new CellRangeAddress(RowNum,cell-1,scenarioNameColumnIndex,scenarioNameColumnIndex));
//		ExcelWSheet.addMergedRegion(new CellRangeAddress(RowNum,cell-1,statusColumnIndex,statusColumnIndex));
		
		FileOutputStream fileOut = new FileOutputStream(filePath);
		ExcelWBook.write(fileOut);
		fileOut.flush();
		fileOut.close();
		ExcelWBook.close();
				
	}
	
	public static String getKeyOfMap(Map<String, String> map, String value){
		for(String key : map.keySet()){
		      if(map.get(key).equals(value)){
		    	  return key;
		      }
		}
		return null;		      
	}
	
	   public static void GenerateMasterthoughtReport(){
	        try{
	            String RootDir = System.getProperty("user.dir");
	            File reportOutputDirectory = new File(RootDir+"target\\Masterthought");
	            List<String> list = new ArrayList<String>();
	            list.add(RootDir+"target\\cucumber.json");
	            
	            String pluginUrlPath = "";
	            String buildNumber = "1";
	            String buildProject = "cucumber-jvm";
	            boolean skippedFails = true;
	            boolean pendingFails = true;
	            boolean undefinedFails = true;
	            boolean missingFails = true;
	            boolean flashCharts = true;
	            boolean runWithJenkins = false;
	            boolean highCharts = false;
	            boolean parallelTesting = true;
	            boolean artifactsEnabled = false;
	            String artifactConfig = "";

	            Configuration configuration = new Configuration(reportOutputDirectory, "SCM_Automation");
	         // optionally only if you need
	         configuration.setStatusFlags(skippedFails, pendingFails, undefinedFails, missingFails);
	         //configuration.setParallelTesting(parallelTesting);
	         //configuration.setJenkinsBasePath("jenkinsBasePath");
	         //configuration.setRunWithJenkins(runWithJenkins);
	         //configuration.setBuildNumber(buildNumber);

	         ReportBuilder reportBuilder = new ReportBuilder(list, configuration);
	         reportBuilder.generateReports();
	            
	            
//	            ReportBuilder reportBuilder = new ReportBuilder(list, reportOutputDirectory, pluginUrlPath, buildNumber,
//	                    buildProject, skippedFails, pendingFails, undefinedFails, missingFails, flashCharts, runWithJenkins,
//	                    highCharts, parallelTesting);

//	            ReportBuilder reportBuilder = new ReportBuilder(list, reportOutputDirectory, pluginUrlPath, buildNumber,
//	                    buildProject, skippedFails, undefinedFails, flashCharts, runWithJenkins, artifactsEnabled, artifactConfig,
//	                    highCharts);
	            reportBuilder.generateReports();
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	    }
	   
	   public static void getResultThroughPlugin() throws Exception
	   {
		   CucumberResultsOverview results = new CucumberResultsOverview();
		   results.setOutputDirectory("target");
		   results.setOutputName("cucumber-results");
		   results.setSourceFile("./target/cucumber.json");
		   results.executeFeaturesOverviewReport();
	   }
	   
	   public static void getResultThroughPlugin2() throws Exception
	   {
		   CucumberUsageReporting report = new CucumberUsageReporting();
		   report.setOutputDirectory("target");
		   report.setJsonUsageFile("./target/cucumber.json");
		   report.executeReport();
	   }
	   
	   public static void updateLoggerForAPI(String apiAction, String actualResponesMesg, String expectedResponseMessage){
		   if (expectedResponseMessage.equalsIgnoreCase(actualResponesMesg)){
			   logger.info(actualResponesMesg+ " message is displaying on performing "+apiAction+" action");
		   }
		   else{
			   logger.error("Incorrect response messgae "+actualResponesMesg+" is displaying on performing "+apiAction+"");
		   }
	   }
	   
	   public String getProjectPath(String key) throws IOException {
	
			
			final Properties properties = new Properties();
			System.out.println(key);
			properties.load(this.getClass().getClassLoader().getResourceAsStream("constants.properties"));
			System.out.println(properties.getProperty(key));
			return properties.getProperty(key);
	}	
    
	public static void verifyPOCalculation(List<Map<String, String>> productListMap,List<Map<String, String>> orderProductMap, Object[] productName, String poName, String reatilerID) throws NumberFormatException, Exception{
		
		DBUtil dbClass = new DBUtil();
		Calculation calculatePO = new Calculation();
		Map<String, String> calculatedValues = new HashMap<String, String>();
		
//		DecimalFormat df = new DecimalFormat("##.00");
//		HashMap<String, String> map = new HashMap<String, String>();
		
		double grossAmount = 0;
		double totaltaxAmount = 0;
		double grandTotal = 0;
		
		String margin=null,DP=null,VAT=null,CST=null,packOf=null,QTY=null;
		
		for (int i=0;i<productName.length;i++){
			Map<String, String> prductConfigDetails = getMapOfListMap(productListMap, "Name", productName[i].toString());
			Map<String, String> orderProducConfig = getMapOfListMap(orderProductMap, "Name", productName[i].toString());
				if (prductConfigDetails.containsKey("JBL Margin")) margin = prductConfigDetails.get("JBL Margin");
				if (prductConfigDetails.containsKey("DP")) DP = productListMap.get(0).get("DP");
				if (prductConfigDetails.containsKey("CST")) CST = prductConfigDetails.get("CST");
				if (prductConfigDetails.containsKey("VAT")) VAT = prductConfigDetails.get("VAT");
				if (prductConfigDetails.containsKey("pack Of")) packOf = prductConfigDetails.get("pack Of");
				QTY = orderProducConfig.get("Qty");
				if (prductConfigDetails.get("Stateid").equals(reatilerID) == false) {
					calculatedValues = calculatePO.calculateInterStatevalues(margin, DP, VAT, CST, QTY,packOf);}
				else{
					calculatedValues = calculatePO.calculateIntraStateValues(margin, DP, VAT, QTY,packOf);}

				
				System.out.println(calculatedValues.get("Gross Amount"));
				System.out.println(calculatedValues.get("Tax Amount"));
				System.out.println(calculatedValues.get("Grand Total"));
				
				grossAmount = grossAmount+Double.parseDouble(calculatedValues.get("Gross Amount"));
				totaltaxAmount = totaltaxAmount+Double.parseDouble(calculatedValues.get("Tax Amount"));
				grandTotal = grandTotal+Double.parseDouble(calculatedValues.get("Grand Total"));		
		}
		
		
		Double expectedSubTotal = Double.parseDouble(dbClass.getSingleData("subtotal", "stock_po", "po_no", poName));
		Double expectedTotalTax = Double.parseDouble(dbClass.getSingleData("total_tax_amt", "stock_po", "po_no", poName)); 
		Double expectedGrandTotal =Double.parseDouble(dbClass.getSingleData("total", "stock_po", "po_no", poName)); 

		System.out.println("Sub Total Amount in db:" + expectedSubTotal);
		System.out.println("Sub Total Amount through calculation: "+grossAmount);
		System.out.println("Total Tax Amount in db:"+ expectedTotalTax);
		System.out.println("Total Tax Amount through calculation: "+totaltaxAmount);
		System.out.println("Grand Total Amount in db: " + expectedGrandTotal);
		System.out.println("Grand Total Amount through calculation: "+ grandTotal);


		Assert.assertEquals(CommonMethods.almostEqual(expectedSubTotal,grossAmount,0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(expectedTotalTax,totaltaxAmount,0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(expectedGrandTotal,grandTotal,0.5),true);
		
	}
		

	
	public static Map<String, String> getMapOfListMap(List<Map<String, String>> productListMap, String keyName, String keyValue)
	{
		for (int j=0;j<productListMap.size();j++){
			if  (productListMap.get(j).get(keyName)==keyValue){
				return productListMap.get(j);
				
			}
		}
		return null;
	}

}
