package reusable;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class Calculation {

	public Map<String,String> calculateInterStatevalues(String margin, String DP, String VAT, String CST, String QTY, String packOf)
	{
		double Margin = (Double.parseDouble(DP)*(Double.parseDouble(margin)/100));
		double BP = ((Double.parseDouble(DP)-Margin)/(1+(Double.parseDouble(VAT)/100))/(1+(Double.parseDouble(CST)/100)));
		System.out.println("BP:"+ getROundOff(BP));
		double BPPerPiece = getROundOff(BP)/Double.parseDouble(packOf);
		System.out.println("BPPerPiece:"+ getROundOff(BPPerPiece));
		double grossAmt = getROundOff(BPPerPiece)*Double.parseDouble(QTY)*Double.parseDouble(packOf);
		double taxAmt = (grossAmt*(Double.parseDouble(CST)/100));
		double grandTotal = grossAmt+taxAmt;

		DecimalFormat df = new DecimalFormat("##.00");
		HashMap<String, String> map = new HashMap<String, String>();

		map.put("Margin", df.format(Margin));
		map.put("BP", df.format(BP));
		map.put("Gross Amount", df.format(grossAmt));
		map.put("Grand Total", df.format(grandTotal));
		map.put("Tax Amount", df.format(taxAmt));

		return map;
	}
	
	public Map<String,String> calculateIntraStateValues(String margin,String DP,String VAT,String QTY, String packOf)
	{

		double Margin = (Double.parseDouble(DP)*(Double.parseDouble(margin)/100));
		double BP = ((Double.parseDouble(DP)-Margin)/(1+(Double.parseDouble(VAT)/100)));
		System.out.println("BP:"+ getROundOff(BP));
		double BPPerPiece = getROundOff(BP)/Double.parseDouble(packOf);
		System.out.println("BPPerPiece:"+ getROundOff(BPPerPiece));
		double grossAmt = getROundOff(BPPerPiece)*Double.parseDouble(QTY)*Double.parseDouble(packOf);
		double taxAmt = (grossAmt*(Double.parseDouble(VAT)/100));
		double grandTotal = grossAmt+taxAmt;

		DecimalFormat df = new DecimalFormat("##.00");
		HashMap<String, String> map = new HashMap<String, String>();

		map.put("Margin", df.format(Margin));
		map.put("BP", df.format(BP));
		map.put("Gross Amount", df.format(grossAmt));
		map.put("Grand Total", df.format(grandTotal));
		map.put("Tax Amount", df.format(taxAmt));

		return map;
	}

	public double getROundOff(double value)
	{
		DecimalFormat df = new DecimalFormat("##.00");
		return Double.parseDouble(df.format(value));
	}
}
