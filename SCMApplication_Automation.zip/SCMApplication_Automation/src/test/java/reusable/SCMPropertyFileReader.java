package reusable;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import dataGenerator.Util;

public class SCMPropertyFileReader {
	
	public static String GetValue(String key)
	{
		// Read from properties file
		File file = new File("src\\main\\resources\\constant.properties");

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		//load properties file
		try {
			prop.load(fileInput);
		} catch (Exception e) {
			e.printStackTrace();
		}

		//Open the URL in firefox browser
		String strbaseURL = prop.getProperty(key);
		// return the base url value
		return strbaseURL;
	}

}
