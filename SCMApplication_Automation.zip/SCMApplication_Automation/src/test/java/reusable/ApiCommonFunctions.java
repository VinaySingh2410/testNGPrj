package reusable;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.path.json.JsonPath;

import api_Executor.ExecuteRequest;
import dataGenerator.CreateApproavedProduct;
import dataGenerator.MD5Generator;
import dataGenerator.PropertyFileReader;
import dataGenerator.Util;
import pojoClasses.AddToCartReq;
import pojoClasses.GenerateOrderReq;
import pojoClasses.PaymentResponseReq;
import pojoClasses.ProductList;
import pojoClasses.Retailerlogin;
import pojoClasses.ShippingAdd;
import pojoClasses.UpdateOrderReq;
import pojoClassesNew.AddtocartreqNew;
import pojoClassesNew.GenrateOrderReqNew;
import pojoClassesNew.ListToCartReqNew;
import pojoClassesNew.ProductListNew;
import pojoClassesNew.UpdateOrderNew;

public class ApiCommonFunctions {

	public String generateOrderAndVerify(List<Map<String, String>> data, String mobileNumber, Map<String, String> productName) throws Exception
	{
		DBUtil dbClass = new DBUtil();
		
		 String retailer_digestString = new MD5Generator().getDigestString(mobileNumber);
		 long retailer_timestamp= CreateApproavedProduct.getTimeStamp();
    	 ResultSet rs = dbClass.getResultSet("client_master", "mobileno", mobileNumber);
		 String retailer_imeiNo =dbClass.getSingleValueFromResultSet(rs, "imeino");
		 String retailer_deviceType =dbClass.getSingleValueFromResultSet(rs, "device_type");
		 String retailer_deviceToken = dbClass.getSingleValueFromResultSet(rs, "device_token_id");
		 String retaler_memberID =dbClass.getSingleValueFromResultSet(rs, "member_id");
		 rs.close(); 
		
		 String productID = null;
		 String url;
		 String retailerID = retaler_memberID;
		 String cart_amount = null;
		 ExecuteRequest executeRequest = new ExecuteRequest();

		//Post add to cart request and get the cart amount from the response.
		for (int i=0;i<data.size();i++)
		{
			//Add To Cart
			url = Util.getAPIURL()+"/Cart/addCartItem/format/json";
			productID = dbClass.getDBvalue("id", "SELECT * FROM `seller_product` WHERE `product_name` = '"+productName.get(data.get(i).get("Name"))+"'");
			AddToCartReq addToCartReq = new AddToCartReq(retailerID, mobileNumber);
			addToCartReq.setDeviceToken(retailer_deviceToken);
			addToCartReq.setDeviceType(retailer_deviceType);
			addToCartReq.setDigestString(retailer_digestString);
			addToCartReq.setImeiNo(retailer_imeiNo);
			addToCartReq.setRetailerId(retailerID);
			addToCartReq.setTimestamp(Long.toString(retailer_timestamp));
			addToCartReq.setProductId(productID);
			addToCartReq.setCartonCount(Integer.parseInt(data.get(i).get("Qty")));
			JsonPath addTocartRes = executeRequest.Execute(addToCartReq,url);
			CommonMethods.updateLoggerForAPI("Add To cart",addTocartRes.getString("message"),"Product added Successfully!");
			cart_amount = addTocartRes.getString("cart_amount");	
		}

		//Post the generate order request and get the order number from the response.
		url = Util.getAPIURL()+"/Order/generateOrder/format/json";
		GenerateOrderReq generateOrderReq = new GenerateOrderReq(retailerID, mobileNumber);
		
		generateOrderReq.setDeviceToken(retailer_deviceToken);
		generateOrderReq.setDeviceType(retailer_deviceType);
		generateOrderReq.setDigestString(retailer_digestString);
		generateOrderReq.setImeiNo(retailer_imeiNo);
		generateOrderReq.setRetailerId(Integer.parseInt(retailerID));
		generateOrderReq.setTimestamp(Long.toString(retailer_timestamp));
		
		generateOrderReq.setCodAmt(Integer.parseInt(cart_amount));
		generateOrderReq.setTotalAmt(Integer.parseInt(cart_amount));
		ShippingAdd shippingAdd = new ShippingAdd();
		shippingAdd.setMobileno(mobileNumber);
		ArrayList<ProductList> productList = new ArrayList<ProductList>();
		for (int i=0;i<data.size();i++)
		{
			ProductList pl = new ProductList();
			productID = dbClass.getDBvalue("id", "SELECT * FROM `seller_product` WHERE `product_name` = '"+productName.get(data.get(i).get("Name"))+"'");
			pl.setProductId(Integer.parseInt(productID));
			pl.setQuantity(Integer.parseInt(data.get(i).get("Qty")));
			productList.add(pl);
		}
		generateOrderReq.setProductList(productList);
		JsonPath jsonPath = executeRequest.Execute(generateOrderReq,url);
		CommonMethods.updateLoggerForAPI("Generate Order",jsonPath.getString("message"),"In Process");
		String generatedOrderNumber = jsonPath.getString("order_number");

		//Post request of update order.
		url = Util.getAPIURL()+"/Order/updateOrder/format/json";
		UpdateOrderReq updateOrderReq = new UpdateOrderReq(retailerID, mobileNumber);
		
		updateOrderReq.setDeviceToken(retailer_deviceToken);
		updateOrderReq.setDeviceType(retailer_deviceType);
		updateOrderReq.setDigestString(retailer_digestString);
		updateOrderReq.setImeiNo(retailer_imeiNo);
		updateOrderReq.setRetailerId(retailerID);
		updateOrderReq.setTimestamp(Long.toString(retailer_timestamp));
		
		updateOrderReq.setReferenceId(generatedOrderNumber);
		updateOrderReq.setOrderId(generatedOrderNumber.substring(generatedOrderNumber.length()-6));
		JsonPath updateOrderJson =executeRequest.Execute(updateOrderReq,url);	
		CommonMethods.updateLoggerForAPI("Update Order",updateOrderJson.getString("message"),"Processed");
		

		//Post request of payment response.
		url = Util.getAPIURL()+"/Order/payment_response/format/json";
		PaymentResponseReq paymentResponseReq = new PaymentResponseReq(retailerID, mobileNumber);
		
		paymentResponseReq.setDeviceToken(retailer_deviceToken);
		paymentResponseReq.setImeiNo(retailer_imeiNo);
		paymentResponseReq.setRetailerId(retailerID);
		
		paymentResponseReq.setOrderId(generatedOrderNumber.substring(generatedOrderNumber.length()-6));
		JsonPath paymentJson =executeRequest.Execute(paymentResponseReq,url);
		CommonMethods.updateLoggerForAPI("Payment the Order",paymentJson.getString("tran_message"),"Transaction Successful");
		return generatedOrderNumber;

	}

	public String orderPunchNewApi(List<Map<String, String>> data, String mobileNumber, Map<String, String> productName) throws Exception
	{
		System.out.println("==================================execution started for add to cart new api====================================");
		DBUtil dbClass = new DBUtil();
		String productID = null;
		String retailerID = dbClass.getDBvalue("member_id",dbClass.createQueryWithCondition(PropertyFileReader.GetValue("client_Master"), "mobileno", mobileNumber));//data.get(0).get("retailerid");
		ExecuteRequest executeRequest = new ExecuteRequest();
		String cart_amount = null;
		
		for (int i=0;i<data.size();i++)
		{
			String url = Util.getAPIURL()+"/Cart/addCartItem/format/json";
			productID = dbClass.getDBvalue("id", "SELECT * FROM `seller_product` WHERE `product_name` = '"+productName.get(data.get(i).get("Name"))+"'");
			if(productID != null)
			{
				System.out.println(productID+" "+" product id created");
			}
			else
			{
				throw new Exception("PRODUCT NOT GENERATED");
			}
			AddtocartreqNew addtocartnew = new AddtocartreqNew(retailerID,mobileNumber);
			//addtocartnew.setUid(retailerID);
			addtocartnew.setProduct_id(productID);
			int qty = Integer.parseInt(data.get(i).get("Qty"));
			addtocartnew.setCarton_count(qty);
			JsonPath addTocartRes = executeRequest.Execute(addtocartnew,url);
			CommonMethods.updateLoggerForAPI("Add To cart",addTocartRes.getString("message"),"Product added Successfully!");
			System.out.println("==================================execution started for add to cart new api====================================");
		}
		//list to cart 
		String url = Util.getAPIURL()+"/Cart/listCartItems/format/json";
		ListToCartReqNew listocart = new ListToCartReqNew(retailerID,mobileNumber);
		JsonPath listtocartRes = executeRequest.Execute(listocart,url);
		String cartamount = listtocartRes.getString("cart_amount");
		System.out.println(cartamount+"  ....................");
		
		//generate order
		String url2 = Util.getAPIURL()+"/Order/generateOrder/format/json";
		GenrateOrderReqNew generateOrder = new GenrateOrderReqNew(retailerID,mobileNumber);
		generateOrder.setCod_amt(cartamount);
		generateOrder.setTotal_amt(cartamount);
		ShippingAdd shippingAdd = new ShippingAdd();
		shippingAdd.setMobileno(mobileNumber);
		ArrayList<ProductListNew> productList = new ArrayList<ProductListNew>();
		for (int i=0;i<data.size();i++)
		{
			ProductListNew pl = new ProductListNew();
			productID = dbClass.getDBvalue("id", "SELECT * FROM `seller_product` WHERE `product_name` = '"+productName.get(data.get(i).get("Name"))+"'");
			pl.setProduct_id(Integer.parseInt(productID));
			pl.setQuantity(Integer.parseInt(data.get(i).get("Qty")));
			productList.add(pl);
		}
		generateOrder.setProduct_list(productList);
		JsonPath generateOrderRes = executeRequest.Execute(generateOrder,url2);
		String order_number = generateOrderRes.getString("order_number");
		String order_id = generateOrderRes.getString("order_id"); 
		System.out.println(order_number+"  ....................");
		
		//Update order
		String url3 = Util.getAPIURL()+"/Order/updateOrder/format/json";
		UpdateOrderNew updateordernew = new UpdateOrderNew( retailerID, mobileNumber);
		updateordernew.setCod(cartamount);
		updateordernew.setReference_id(order_number.trim());
		updateordernew.setOrder_id(order_id);
		JsonPath updateordernewRes = executeRequest.Execute(updateordernew,url3);
		return order_number;
	}
	
	public void loginWiIthRetailer(String mobileNumber) throws Exception
	{
		ExecuteRequest executeRequest = new ExecuteRequest();
		new DBUtil();
		String url;
		//new CreateApproavedProduct().getMemberID(mobileNumber);
		if (PropertyFileReader.GetValue("apiCall").equalsIgnoreCase("newAPI")){
		url = Util.getAPIURL()+"/Clientlogin/clientlogin/format/json";}
		else{
			url = Util.getAPIURL()+"/Clientlogin/clientlogin/format/json";}
		Retailerlogin loginWithRetailer = new Retailerlogin(mobileNumber);
		executeRequest.Execute(loginWithRetailer, url);
	}

}
