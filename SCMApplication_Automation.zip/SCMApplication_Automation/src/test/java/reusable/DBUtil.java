package reusable;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.testng.annotations.Test;

import dataGenerator.PropertyFileReader;

public class DBUtil {
	Connection conn;
	String dbUrl = PropertyFileReader.GetValue("dbUrl");
	String username = PropertyFileReader.GetValue("dbUsername");
	String password = PropertyFileReader.GetValue("dbPassword");
	Statement stmt;
	ResultSet rs = null;

	private void init() throws Exception {
		try {
			// Load mysql jdbc driver
			Class.forName("com.mysql.jdbc.Driver");
			// Create Connection to DB
			//PropertyFileReader.GetValue("JDBCURL") + "?"+ "user=" + PropertyFileReader.GetValue("DBUser") + "&password=" + PropertyFileReader.GetValue("DBPass"));
			//Connection con = DriverManager.getConnection(dbUrl, username, password);
			
			Connection con = DriverManager.getConnection(dbUrl + "?"+ "user=" + username + "&password=" + password);
			
			// Create Statement Object
			stmt = con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String[][] getResultSet(String selectQuery) throws Exception {
		try {
			init();
			rs = stmt.executeQuery(selectQuery);
			ResultSetMetaData rsmd = rs.getMetaData();

			int size = 0;
			if (rs != null) {
				rs.beforeFirst();
				rs.last();
				size = rs.getRow();
				// Column count in query
				int cols = rsmd.getColumnCount();
				String[][] array = new String[size][cols];
				rs.beforeFirst();
				// Copy all records into array
				int row = 0;
				int j = 0;
				int rowset = 0;
				while (rowset <= size - 1) {
					while (rs.next()) {
						j = 0;
						while (j < cols - 1) {
							array[row][j] = rs.getString(j + 1);
							j++;
						}
						row++;
					}
					rowset++;
				}
				rs.close();
				// Close Connection object
				conn.close();
				// return 2D array values
				return array;
			} else {
				rs.close();
				conn.close();
				return null;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public String getDBvalue(String columnName, String selectQuery) throws Exception {
		try {
			String val = null;
			init();
			
			rs = stmt.executeQuery(selectQuery);
            if (rs == null)
				return null;
			else {
				rs.beforeFirst();
				rs.next();
				val = rs.getString(columnName);
				
			}

			rs.close();
			// conn.close();
			return val;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public String[] getDBvalueArray(String columnName, String selectQuery) throws Exception {
		try {
			init();
			String[] val = new String[50];
			int i=1;
			if (rs == null)
				return null;
			
			else
				while (rs.next()) {
			    
			    	val[i] = (String) rs.getObject(columnName);
			    	i++;
			}
						
		   rs.close();
			// conn.close();
			return val;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	
	public ArrayList<String> fetchData(String id, String tbname, String fld, String arg) throws Exception {
		init();
		ArrayList<String> value = new ArrayList<String>();// value = new String[50];
		
		rs = stmt.executeQuery("SELECT "+id+" FROM `"+tbname+"` WHERE `"+fld+"` LIKE '" + arg + "' ORDER BY "+id+"");
		rs.beforeFirst();
		while (rs.next()) {
			value.add(rs.getString(id));  	
			//System.out.println(value[i]);
			
  		}
		rs.close();
  		return value;
	}
	
	public String getSingleData(String id, String tbname, String fld, String arg) throws Exception {
		init();
		String value;
		
		rs = stmt.executeQuery("SELECT "+id+" FROM `"+tbname+"` WHERE `"+fld+"` LIKE '" + arg + "' ORDER BY "+id+"");
		rs.beforeFirst();
		rs.next();
		value = rs.getString(id);
		rs.close();
  		return value;
	}
	
	public ArrayList<String> getDataFromResultSet(ResultSet rs, String columnName) throws SQLException
	{
		ArrayList<String> value = new ArrayList<String>();
		rs.beforeFirst();
		while (rs.next()) {
			value.add(rs.getString(columnName));  	

  		}
		return value;
	}
	
	public String getSingleValueFromResultSet(ResultSet rs, String columnName) throws SQLException
	{
		String value;
		
		rs.beforeFirst();
		rs.next();
		value= rs.getString(columnName);  	
     	return value;
	}
	public ResultSet getResultSet(String tbname, String fld, String arg) throws Exception
	{
		init();
		rs = stmt.executeQuery("SELECT * FROM `"+tbname+"` WHERE `"+fld+"` LIKE '" + arg + "'");
		rs.beforeFirst();
		//rs.next();
		return rs;
		
	}
	
	@Test
	public void getDataForTesting() throws Exception
	{
		String ab = getDBvalue("invoice_no", "SELECT * FROM `retailer_invoice` WHERE `picklist_id` = (SELECT id FROM `jbl_picklist` WHERE `picklist_no` = '0000035/16-17/P0000018497')");
		System.out.println(ab);
		
//		ArrayList<String> arr = fetchIDForSingleProduct("picklist_no", "jbl_picklist", "order_id", "210327");
//		System.out.println(arr.toArray().length);
//		//System.out.println(fetchIDForSingleProduct("picklist_no", "jbl_picklist", "order_id", "210327").toString());
		
		//String columnName = "picklist_no";
		//System.out.println(getDBvalueArray("picklist_no", "SELECT "+columnName+" FROM `jbl_picklist` WHERE `order_id` = 210327"));
	}
	
	public boolean verifyfromDB(String selectQuery) throws Exception {
		try {
			boolean flag = false;
			init();
			rs = stmt.executeQuery(selectQuery);
			if (rs == null)
				flag = false;
			else
				flag = true;

			rs.close();
			// conn.close();

			return flag;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public void updateTable(String columnName, String columnValue, String conditionColumnNme,String conditionColumnValue) throws Exception {

		// Load mysql jdbc driver
		Class.forName("com.mysql.jdbc.Driver");
		// Create Connection to DB
		Connection con = DriverManager.getConnection(dbUrl, username, password);

		String query = "UPDATE seller_warehouse_quantity SET " + columnName + " = ? WHERE " + conditionColumnNme
				+ " = ?";
		PreparedStatement preparedStmt = con.prepareStatement(query);
		preparedStmt.setString(1, columnValue);
		preparedStmt.setString(2, conditionColumnValue);

		// execute the java preparedstatement
		preparedStmt.executeUpdate();
		con.close();
	}

	public void updateValueInTable(String tableName, String columnName, String columnValue, String conditionColumnNme,String conditionColumnValue) throws Exception {


		// Load mysql jdbc driver
		Class.forName("com.mysql.jdbc.Driver");
		// Create Connection to DB
		Connection con = DriverManager.getConnection(dbUrl, username, password);
		String query = "UPDATE " + tableName + " SET " + columnName + " = ? WHERE " + conditionColumnNme + " = ?";
		PreparedStatement preparedStmt = con.prepareStatement(query);
		preparedStmt.setString(1, columnValue);
		preparedStmt.setString(2, conditionColumnValue);

		// execute the java preparedstatement
		preparedStmt.executeUpdate();
		con.close();
	}

	public String createSQLQuery(String tableName) throws Exception {
		String query = "SELECT * FROM " + tableName + "";
		return query;
	}

	public String createQueryWithCondition(String tableName, String key, String value) throws Exception {
		String query = "SELECT * FROM " + tableName + " WHERE " + key + " = " + value + "";
		return query;
	}

	public String createLikeQuery(String tableName, String key, String value) throws Exception {
		String query = "SELECT * FROM " + tableName + " WHERE " + key + " Like " + value + "";
		return query;
	}

	public String createQueryWithCondition(String tableName, String key, String value, String secondKey,
			String secondValue) throws Exception {
		String query = "SELECT * FROM " + tableName + " WHERE " + key + " = " + value + " AND " + secondKey + "="
				+ secondValue + "";
		return query;
	}

	public String getStateIDOfRetailer(String retailerID) throws Exception {
		String personalID = getDBvalue("personalpincode",
				"Select * from `client_master` WHERE `member_id` = " + retailerID + "");
		String stateID = getDBvalue("state_id", "SELECT * FROM `pincode_master` WHERE `id` = " + personalID + "");
		return stateID;
	}
}
