package reusable;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

public class TestResults {

	public  String status,orderNumber, scenarioName;
	public Map<String, String> productMap = new HashMap<String, String>();
	public Map<String, String> POMap = new HashMap<String, String>();
	public long totalTimeTaken;
	public String ILPProcessing, AGNStatus, GRNStatus, PicklistStatus, RIStatus, LMDStatus;
	public Multimap<String, String> sellerProductMap = ArrayListMultimap.create();

	
	public Multimap<String, String> getsellerProductMap() {
		return sellerProductMap;
	}
	public void setsellerProductMap(Multimap<String, String> sellerProductMap) {
		this.sellerProductMap = sellerProductMap;
	}
	
	public void setPOMap(Map<String, String> POMap) {
		this.POMap = POMap;
	}

	public Map<String, String> getPOMap() {
		return POMap;
	}
	
	public String getILPProcessing() {
		return ILPProcessing;
	}
	public void setILPProcessing(String ILPProcessing) {
		this.ILPProcessing = ILPProcessing;
	}
	public String getAGNStatus() {
		return AGNStatus;
	}
	public void setAGNStatus(String AGNStatus) {
		this.AGNStatus = AGNStatus;
	}
	public String getGRNStatus() {
		return GRNStatus;
	}
	public void setGRNStatus(String GRNStatus) {
		this.GRNStatus = GRNStatus;
	}
	public String getPicklistStatus() {
		return PicklistStatus;
	}
	public void setPicklistStatus(String PicklistStatus) {
		this.PicklistStatus = PicklistStatus;
	}
	public String getRIStatus() {
		return RIStatus;
	}
	public void setRIStatus(String RIStatus) {
		this.RIStatus = RIStatus;
	}
	public String getLMDStatus() {
		return LMDStatus;
	}
	public void setLMDStatus(String LMDStatus) {
		this.LMDStatus = LMDStatus;
	}
	public String getScenarioName() {
		return scenarioName;
	}
	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setProductMap(Map<String, String> productMap) {
		this.productMap = productMap;
	}

	public Map<String, String> getProductMap() {
		return productMap;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
}
