package CommonHooks;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import dataGenerator.PropertyFileReader;
import dataGenerator.Util;
import pages.LMDPage;
import pages.LoginPage;
import pages.OrderPage;
import reusable.CommonMethods;
import reusable.SCMPropertyFileReader;
import reusable.TestResults;


public class Hooks {

	public static WebDriver driver;
	public static LoginPage  loginPage;
	public static OrderPage orderPage;
	public static LMDPage lmdPage;
	public static TestResults testResult;
	static final Logger logger = Logger.getLogger(CommonMethods.class.getName());
	
	@Before
	public void setup(Scenario scenario) throws Exception {
		
		logger.info("Execution of scenario "+scenario.getName()+" has been started.");
		
		driver = CommonMethods.startBrowser(PropertyFileReader.GetValue("BrowserName"),Util.getSCMURL());
		loginPage = PageFactory.initElements(driver, LoginPage.class);
		orderPage = PageFactory.initElements(driver, OrderPage.class);
		lmdPage = PageFactory.initElements(driver, LMDPage.class);
		testResult = new TestResults();
		loginPage.login("sneha.ingale", "sneha123");
	}
	@After
	public void tearDown(Scenario scenario) throws Exception
	{
		if(scenario.isFailed()) {
        try {
		       	 
            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
          }
        }
//        System.out.println(scenario.getName());
		testResult.setStatus(scenario.getStatus());
		testResult.setScenarioName(scenario.getName());
		testResult.setStatus(scenario.getStatus());
		CommonMethods.setValueInTestResult(testResult);
	
		//CommonMethods.getResultThroughPlugin();
		//CommonMethods.getResultThroughPlugin2();
		//CommonMethods.GenerateMasterthoughtReport();
		
		driver.quit();
		logger.info("Execution of scenario "+scenario.getName()+" has been Finished.");
		System.out.println("TearDown has been executed");
	}
}
