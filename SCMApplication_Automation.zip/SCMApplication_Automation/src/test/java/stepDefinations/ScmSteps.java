package stepDefinations;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit; 
import org.junit.Assert; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import CommonHooks.Hooks;
import ch.qos.logback.core.joran.action.Action;
import pages.LMDPage;
import pages.LoginPage;
import pages.OrderPage;
import reusable.CommonMethods;
import reusable.SCMPropertyFileReader;
import reusable.TestResults;

import org.openqa.selenium.WebElement; 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import cucumber.api.java.After; 
import cucumber.api.java.Before; 
import cucumber.api.java.en.Given; 
import cucumber.api.java.en.Then; 
import cucumber.api.java.en.When;
import dataGenerator.PropertyFileReader;

public class ScmSteps {

	protected WebDriver driver;
	protected LoginPage  loginPage;
	protected OrderPage orderPage;
	protected LMDPage lmdPage;
		 
	public ScmSteps (){
		driver = Hooks.driver;
		loginPage = Hooks.loginPage;
		orderPage = Hooks.orderPage;
		lmdPage =  Hooks.lmdPage;

		WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(PropertyFileReader.GetValue("waitTime")));

	}
	

	
	@Given("^I open scuat application$")
	public void I_openApplication() {
		//Set implicit wait of 10 seconds and launch google
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://scuat.justbuylive.com/login/");
	}
	
	@When("^User enter username and password$")
	public void enterUserNameAndPassword() {
		//Write term in google textbox
		WebElement userTextBox = driver.findElement(By.id("id_username"));
		userTextBox.sendKeys("nileshb");
					
		//Click on searchButton
		WebElement passwordTextbox = driver.findElement(By.id("id_password"));
		passwordTextbox.sendKeys("nileshb");
		passwordTextbox.submit();	
	}
	@When("^User LogOut from the Application$")
	public void logoutOfApplication() throws InterruptedException
	{
		WebElement loginPage = driver.findElement(By.linkText("Welcome nileshb"));//driver.findElement(By.id("cwos"));
		//String result = loginPage.getText();
			//System.out.println(result);
		loginPage.click();
		WebElement logoutIcon = driver.findElement(By.className("dropdown-menu")).findElement(By.linkText("logout"));
				logoutIcon.click();
				Thread.sleep(2000);
				
	}
	
	@Then("^Message displayed LogOut Successfully$")
	public void verifyLogoutMsg()
	{
		
		WebElement loginPage = driver.findElement(By.linkText("Log in again"));//driver.findElement(By.id("cwos"));
		Assert.assertEquals(loginPage.isDisplayed(), true);
	}
	@Then("^Login page should display$")
	public void checkLoginPage() throws InterruptedException {
		//Get result from calculator
		Thread.sleep(2000);
		WebElement loginPage = driver.findElement(By.linkText("Welcome nileshb"));//driver.findElement(By.id("cwos"));
		//String result = loginPage.getText();
			//System.out.println(result);
			System.out.println("Pass");
			Assert.assertEquals(loginPage.isDisplayed(), true);
		
		driver.close();
	}
		
	@When("^User navigates on order search page$")
	public void user_navigates_on_order_search_page(){
		orderPage.navigateSearchOrder();
	}

//	@When("^Enter order number in serach field$")
//	public void enter_order_number_in_serach_field() throws Throwable {
//		String orderSearch = CommonMethods.getCellData(1,0);//"0239466/16-17/0000078356";
//		orderPage.searchOrederID(orderSearch);
//	}
//
//	@Then("^serach order should display in result list$")
//	public void serach_order_should_display_in_result_list() throws Exception {
//		String orderNumber = CommonMethods.getCellData(1,0);//"0239466/16-17/0000078356";
//		System.out.println("Verify the search:"+orderPage.verifyOrderInResultList(orderNumber));
//		Assert.assertTrue(orderPage.verifyOrderInResultList(orderNumber));
//	}

	@When("^click on view detail button$")
	public void clickOnViewDetailButton() throws InterruptedException
	{
		orderPage.clickViewDetailBtn();
	}

//	@Then("^verify the orderno is displayed$")
//	public void verifyOrderNumberDisplayed() throws Exception
//	{
//		String orderNumber = CommonMethods.getCellData(1,0);//"0239466/16-17/0000078356";
//		System.out.println("Verify the search:"+orderPage.verifyOrderNoInOrderInfoTable(orderNumber));
//		Assert.assertTrue(orderPage.verifyOrderNoInOrderInfoTable(orderNumber));
//		Thread.sleep(3000);
//	}

	@When("^click on PO No$")
	public void clickPO() throws InterruptedException
	{
		orderPage.clickOnPOLink();
	}
	@Then("^pdf file get opened$")
	public void checkPdfFile()
	{
	     String currentUrl = driver.getCurrentUrl();
	     Assert.assertTrue(currentUrl.contains(".pdf"));
	}
	@Then("^verify warehouse mgmt$")
	public void warehouseMgmt() throws Exception
	{
		
	}
	
//	@Given("^excel data creation part$")
//	public void excel_data_creation_part() throws Throwable {
//		
//		Map<String, String> productMap = new HashMap<String, String>();
//		productMap.put("Dettol", "Dettol _810327");
//		productMap.put("Bisleri", "Bisleri _810327"); 
//		String orderNumber = "ABCXYz-34543545-799889y";
//		
//		Hooks.testResult.setProductMap(productMap);
//		Hooks.testResult.setOrderNumber(orderNumber);
//		
//		System.out.println(Hooks.testResult.getOrderNumber());
//	}
	
//	@Given("^Create and view FPO$")
//	public void createFPOAndViewFPO() throws InterruptedException
//	{
//		
//driver.get("http://scbetanv3.justbuylive.in/wms/view_picklist_details/18998/");
//Thread.sleep(5000);
//
//
//		
//		
//		
////		driver.findElement(By.xpath("//a[@title='Service Provider']")).click();
////		
////		//WebElement dropDown = driver.findElement(By.xpath("//ul[contains(@class,'dropdown-menu')][contains(@style,'block')]"));
////		List<WebElement> abc = driver.findElements(By.xpath("//a[contains(.,'Fulfillment')][contains(@class,'dropdown-toggle')]"));//.click();
////		System.out.println(abc.size());
////		System.out.println(abc.get(0).isDisplayed());
////		System.out.println(abc.get(0).getAttribute("class"));
////		Thread.sleep(500);
////		
////		
////		//WebElement dropDown1 = dropDown.findElement(By.xpath("//ul[contains(@class,'dropdown-menu')][contains(@style,'block')]"));
////		driver.findElement(By.xpath("//a[@title='Create FPO']")).click();
//		//driver.findElement(By.xpath("//*[@id='bs-example-navbar-collapse-1']/ul[1]/li[5]/ul/li[5]/ul/li[1]/a")).click();
//		//driver.findElement(By.xpath("//a[@title='Service Provider'][contains(.,'Service Provider')]//b")).click();
//		//Thread.sleep(1000);
//	//	WebElement dropDown = driver.findElement(By.className("dropdown-menu"));
//	//	Actions action = new Actions(driver);
//
//	//	Actions action = new Actions(driver);
//	//driver.findElement(By.xpath("//li[a[contains(.,'Fulfillment')]]//a[@data-toggle='dropdown']")).click();
//	//Thread.sleep(2000);
//		//		action.moveToElement(linkFullfulment).click().build().perform();
//		//	Thread.sleep(5000);
//			//	action.moveToElement(createFullfulment).click().build().perform();
//		
//		
//		
//			
//			
//			
//			
//		
//		//System.out.println("sbc");
//		//System.out.println(dropDown1.isDisplayed());
//	//	List<WebElement> dropDown2 = dropDown.findElements(By.xpath("//a[@title='Fulfillment']"));
//		//System.out.println(dropDown2.size());
//		//Thread.sleep(500);
//	//	action.moveToElement(dropDown1).build().perform();
//	//	Thread.sleep(1000);
//		//
//	//	driver.findElement(By.xpath("//a[@title='Create FPO']")).click();
//		
//		
//
////		Thread.sleep(3000);
////		driver.findElement(By.xpath("//a[contains(.,'Service Provider')]")).click();
////		Thread.sleep(5000);
////		WebElement linkFullfulment = driver.findElement(By.xpath("//ul[contains(@style,'block')]//li[a[contains(text(),'Fulfillment')][contains(@href,'#')]]"));
////		System.out.println("abc");
////		WebElement createFullfulment = driver.findElement(By.xpath("//ul[contains(@style,'block')]/li//a[@title='Create FPO']"));
////
////	
////		
////		
////		Actions action = new Actions(driver);
////
////		action.moveToElement(linkFullfulment).build().perform();
////		Thread.sleep(5000);
////		action.moveToElement(createFullfulment).click().build().perform();
////		if(driver.findElement(By.xpath("//ul[contains(@style,'block')]//li//a[contains(text(),'Fulfillment')][contains(@href,'#')]")).isDisplayed())
////			{
////			System.out.println("pass");
////			};
////		Thread.sleep(5000);
////		driver.findElement(By.xpath("//ul[contains(@style,'block')]/li//a[@title='Create FPO']")).click();
//		
////		WebElement dropDown = driver.findElement(By.className("dropdown-menu"));
////		Actions action = new Actions(driver);
////		WebElement dropDown1 = dropDown.findElement(By.xpath("//a[@title='Fulfillment']"));
////		Thread.sleep(500);
////		action.moveToElement(dropDown1).build().perform();
////		Thread.sleep(1000);
//		
//		
//	}

}
