package stepDefinations;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import CommonHooks.Hooks;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dataGenerator.CreateApproavedProduct;
import dataGenerator.Offer;
import dataGenerator.PropertyFileReader;
import dataGenerator.Registration;
import dataGenerator.Seller;
import dataGenerator.createProduct;
import pages.LMDPage;
import pages.LoginPage;
import pages.OrderPage;
import reusable.ApiCommonFunctions;
import reusable.Calculation;
import reusable.CommonMethods;
//import pages.LMDPage;
import reusable.DBUtil;
import reusable.SCMPropertyFileReader;
import reusable.TestResults;

public class ApiSteps {

	List<Map<String, String>> data;
	List<Map<String, String>> productListMap;
	List<Map<String, String>> orderProductmap;
	protected WebDriver driver;
	protected OrderPage orderPage;
	protected LoginPage loginPage;
	protected LMDPage lmdPage;
	protected WebDriverWait wait;
	
	DBUtil dbClass = new DBUtil();
	public String productID;
	public String orderNumber;
	public String sellerID;
	public String fpoProductName;
	public String wareHouserQuantity;
	public String pOLinkName;
	public String wareHouseID;
	public String quantity;
	public String stateID;
	public String sellerStateID;
	public String retailerStateID;
	public String margin;
	public String packOf;
	public String VAT;
	public String CST;
	public String DP;
	public String pickListname;
	public String retailerName;
	public String sellerName;
	public String productName;
	public String qtyInJit;
	public String buyQuantity;
	public String purchasedProduct;
	public String offeredProduct;
	public String offerDiscountType;
	public String percentageOffer;
	public String getQuantity;
	public String getPackOf;
	public String buyPackOf;
	public String discountDetailsType;
	public String brandName = null;
	public String offerDiscountValue = null;
	public String offerID = null;
	public Map<String, String> productDetailsMap = new HashMap<String, String>();
	public Map<String, String> productDPMap = new HashMap<String, String>();
	String[] productsNameArr = new String[20];
	public Map<String, String> picklistNumberMap = new HashMap<String, String>();
	public Map<String, String> retailerInvoiceMap = new HashMap<String, String>();
	public Map<String, String> picklistAndInvoiceMap = new HashMap<String, String>();
	public Map<String, String> POMap = new HashMap<String, String>();
	Multimap<String, String> sellerProductMap = ArrayListMultimap.create();
	public Map<String, String> sellerPOMap = new HashMap<String, String>();

	// Stores database table names.
	public String sellerProduct_TableName = "seller_product";
	public String jblInventory_TableName = "jbl_inventory";
	public String productPrice_TableName = "product_price";
	public String productMargin_TableName = "product_margin";
	public String productTax_TableName = "product_tax";
	public String stockPO_TableName = "stock_po";
	public String jbl_Picklist = "jbl_picklist";
	public String retailer_invoice = "retailer_invoice";
	TestResults testResult;
	static final Logger logger = Logger.getLogger(CommonMethods.class.getName());

	public ApiSteps (){
		driver = Hooks.driver;
		loginPage = Hooks.loginPage;
		orderPage = Hooks.orderPage;
		lmdPage =  Hooks.lmdPage;
		testResult = Hooks.testResult;
		wait = new WebDriverWait(driver, Long.parseLong(PropertyFileReader.GetValue("waitTime")));
		//WebElement element = wait.until(ExpectedConditions.visibilityOf(element)));
	}

	/* Add the offer to the products */
	@And("^product offer is$")
	public void the_product_offer_is(DataTable table) throws Exception {
		// Store the data table value ass map.
		data = table.asMaps(String.class, String.class);

		// Initialize the variables.
		if (data.get(0).containsKey("brandName"))
			brandName = data.get(0).get("brandName");
		buyPackOf = data.get(0).get("Buy Pack");
		getPackOf = data.get(0).get("Get Pack");
		buyQuantity = data.get(0).get("Buy");
		purchasedProduct = productDetailsMap.get(data.get(0).get("Purchased Product"));
		offeredProduct = productDetailsMap.get(data.get(0).get("Offered Product"));
		getQuantity = data.get(0).get("GET");
		offerDiscountType = CommonMethods.getOfferTypeID(data.get(0).get("offerDiscountType"));
		offerDiscountValue = data.get(0).get("offerDiscountValue");
		offerID = CommonMethods.getOfferID(data.get(0).get("offerID"));
		discountDetailsType=data.get(0).get("DiscountDetailsType");

		// Create offers for the products.
		Offer createOffer = new Offer();
		createOffer.addOfferToProduct(sellerName, brandName, purchasedProduct, offeredProduct, buyQuantity,
				offerDiscountType, offerDiscountValue, getQuantity, offerID,discountDetailsType);

		// Store the product id of product on which offer is implemented.
		productID = dbClass.getDBvalue("id",
				"SELECT * FROM `seller_product` WHERE `product_name` = '" + purchasedProduct + "'");

	}

	/* Create the seller, if not exist. */
	@Given("^the seller should exists$")
	public void seller_Should_Exists(DataTable table) throws Exception {
		// Store the data table value as map.
		data = table.asMaps(String.class, String.class);

		// Create seller and store the name of created seller.
		Seller createSeller = new Seller();
		for (int i=0;i<data.size();i++){
		createSeller.createSeller(data.get(i).get("sellerName"), data.get(i).get("stateID"), data.get(i).get("isCPO"),
				data.get(i).get("isITC"),data.get(i).get("cityID"),data.get(i).get("pinCode"));
		}
		new CreateApproavedProduct();
		sellerName = data.get(0).get("sellerName");//CreateApproavedProduct.getSellerName();
		logger.info("Seller has been created: "+ sellerName);
	}

	/* Verify that purchased and offered products are displaying properly */
	@And("^purchase and offered product should displayed properly$")
	public void offered_product_displayed_properly() throws InterruptedException {
		driver.findElement(By.id("view_suborder")).click();
		Thread.sleep(5000);
		String actualPurchasedProduct = driver.findElement(By.xpath("//*[@id='myModal1']//table//tr[1]/td[3]"))
				.getText();
		String actualPurchasedProduct12 = driver.findElement(By.xpath("//*[@id='myModal1']//table//tr[1]/td[3]"))
				.getAttribute("data-row-index");
		boolean chkPurchasedProduct = actualPurchasedProduct.contains(purchasedProduct);
		Assert.assertEquals(chkPurchasedProduct, true);

		String actualOfferedProduct = driver
				.findElement(By.xpath("//*[@id='myModal1']/div/div/div[2]/div/table/tbody/tr[2]/td[3]")).getText();
		boolean chkOfferedProduct = actualOfferedProduct.contains(offeredProduct);
		Assert.assertEquals(chkOfferedProduct, true);
		String purchaseProductQty = driver
				.findElement(By.xpath("//*[@id='myModal1']/div/div/div[2]/div/table/tbody/tr[1]/td[4]")).getText();
		boolean chkPurchasedProductQty = purchaseProductQty.contains(buyQuantity);
		Assert.assertEquals(chkPurchasedProductQty, true);

		String offerProductQty = driver
				.findElement(By.xpath("//*[@id='myModal1']/div/div/div[2]/div/table/tbody/tr[2]/td[4]")).getText();
		boolean chkOfferedProductQty = offerProductQty.contains(getQuantity);
		Assert.assertEquals(chkOfferedProductQty, true);
	}


	@Given("^the below product exist in database$")
	public void the_offered_product_exist_in_database(DataTable table) throws Exception {
		data = table.asMaps(String.class, String.class);

		productListMap = data;
		//
		if (data.get(0).containsKey("Stateid"))
			sellerStateID = data.get(0).get("Stateid");
		if (data.get(0).containsKey("JBL Margin"))
			margin = data.get(0).get("JBL Margin");
		if (data.get(0).containsKey("DP"))
			DP = data.get(0).get("DP");
		if (data.get(0).containsKey("CST"))
			CST = data.get(0).get("CST");
		if (data.get(0).containsKey("VAT"))
			VAT = data.get(0).get("VAT");
		if (data.get(0).containsKey("pack Of"))
			packOf = data.get(0).get("pack Of");

		for (int i = 0; i <data.size(); i++) {
			if (data.get(0).containsKey("SellerName")){sellerName=data.get(i).get("SellerName");}
			
			createProduct createProduct = new createProduct();
			productsNameArr[i] = createProduct.createTestProduct(data.get(i).get("Name"), data.get(i).get("RTO INV"),
					data.get(i).get("JBL INV"), data.get(i).get("JIT INV"), sellerName, data.get(i).get("MRP"),
					data.get(i).get("DP"), data.get(i).get("JBL Margin"), data.get(i).get("Tax Type"),
					data.get(i).get("brandName"), data.get(i).get("isFree"), data.get(i).get("pack Of"));

			productDetailsMap.put(data.get(i).get("Name"), productsNameArr[i]);
			logger.info(productsNameArr[i]+ "has been created against the product: "+ data.get(i).get("Name"));
			productDPMap.put(productsNameArr[i], data.get(i).get("DP"));
			sellerProductMap.put(data.get(i).get("SellerName"), data.get(i).get("Name"));
		}
		testResult.setProductMap(productDetailsMap);
		testResult.setsellerProductMap(sellerProductMap);
	}

	@Then("^Verify the quantity get deducted properly$")
	public void verify_the_quantity_get_deducted_properly(DataTable table) throws Exception {
		data = table.asMaps(String.class, String.class);
		for (int i = 0; i < data.size(); i++) {
			String actualProductName = productDetailsMap.get(data.get(i).get("Name"));
			productID = dbClass.getDBvalue("id",
					"SELECT * FROM `seller_product` WHERE `product_name` = '" + actualProductName + "'");
			String wareHouserQuantityQuery = "SELECT * FROM `seller_warehouse_quantity` WHERE `product_id` = '"
					+ productID + "'";
			String actual_WareHouserQuantity = dbClass.getDBvalue("quantity", wareHouserQuantityQuery);
			Assert.assertEquals(actual_WareHouserQuantity, data.get(i).get("Jit INV"));
		}
	}

	@And("^PO calculation should be correct$")
	public void veriy_PO_Calculations() throws Exception {
		Calculation calculatePO = new Calculation();
		if (sellerStateID.equals(retailerStateID) == false) {
			Map<String, String> map = calculatePO.calculateInterStatevalues(margin, DP, VAT, CST, quantity,packOf);

			Double expectedSubTotal = Double.parseDouble(dbClass.getDBvalue("subtotal", dbClass.createQueryWithCondition(stockPO_TableName,
					"order_id", orderNumber.substring(orderNumber.length() - 6))));
			Double expectedTotalTax = Double.parseDouble(dbClass.getDBvalue("total_tax_amt", dbClass.createQueryWithCondition(stockPO_TableName,
					"order_id", orderNumber.substring(orderNumber.length() - 6))));
			Double expectedGrandTotal = Double.parseDouble(dbClass.getDBvalue("total", dbClass.createQueryWithCondition(stockPO_TableName, "order_id",
					orderNumber.substring(orderNumber.length() - 6))));


			System.out.println("Sub Total Amount in db:" + expectedSubTotal);
			System.out.println("Sub Total Amount through calculation: "+Double.parseDouble(map.get("Gross Amount")));
			System.out.println("Total Tax Amount in db:"+ expectedTotalTax);
			System.out.println("Total Tax Amount through calculation: "+Double.parseDouble(map.get("Tax Amount")) );
			System.out.println("Grand Total Amount in db: " + expectedGrandTotal);
			System.out.println("Grand Total Amount through calculation: "+ Double.parseDouble(map.get("Grand Total")));


			Assert.assertEquals(CommonMethods.almostEqual(expectedSubTotal,Double.parseDouble(map.get("Gross Amount")),0.5),true);
			Assert.assertEquals(CommonMethods.almostEqual(expectedTotalTax,Double.parseDouble(map.get("Tax Amount")),0.5),true);
			Assert.assertEquals(CommonMethods.almostEqual(expectedGrandTotal,Double.parseDouble(map.get("Grand Total")),0.5),true);

		}
		if (sellerStateID.equals(retailerStateID) == true) {
			Map<String, String> map = calculatePO.calculateIntraStateValues(margin, DP, VAT, quantity,packOf);

			Double expectedSubTotal = Double.parseDouble(dbClass.getDBvalue("subtotal", dbClass.createQueryWithCondition(stockPO_TableName,
					"order_id", orderNumber.substring(orderNumber.length() - 6))));
			Double expectedTotalTax = Double.parseDouble(dbClass.getDBvalue("total_tax_amt", dbClass.createQueryWithCondition(stockPO_TableName,
					"order_id", orderNumber.substring(orderNumber.length() - 6))));
			Double expectedGrandTotal = Double.parseDouble(dbClass.getDBvalue("total", dbClass.createQueryWithCondition(stockPO_TableName, "order_id",
					orderNumber.substring(orderNumber.length() - 6))));


			System.out.println("Sub Total Amount in db:" + expectedSubTotal);
			System.out.println("Sub Total Amount through calculation: "+Double.parseDouble(map.get("Gross Amount")));
			System.out.println("Total Tax Amount in db:"+ expectedTotalTax);
			System.out.println("Total Tax Amount through calculation: "+Double.parseDouble(map.get("Tax Amount")) );
			System.out.println("Grand Total Amount in db: " + expectedGrandTotal);
			System.out.println("Grand Total Amount through calculation: "+ Double.parseDouble(map.get("Grand Total")));


			Assert.assertEquals(CommonMethods.almostEqual(expectedSubTotal,Double.parseDouble(map.get("Gross Amount")),0.5),true);
			Assert.assertEquals(CommonMethods.almostEqual(expectedTotalTax,Double.parseDouble(map.get("Tax Amount")),0.5),true);
			Assert.assertEquals(CommonMethods.almostEqual(expectedGrandTotal,Double.parseDouble(map.get("Grand Total")),0.5),true);
		}
	}

	@When("^the retailer with Mobile Number \"(.*?)\" orders the product$")
	public void the_retailer_with_Mobile_Number_orders_the_product(String mobileNumber, DataTable table)
			throws Exception {
		data = table.asMaps(String.class, String.class);
		orderProductmap = data;
		buyQuantity = data.get(0).get("Qty");
		Registration registration = new Registration();
		registration.registration(mobileNumber);
		logger.info("Retailer  with mobile number "+mobileNumber+" get registered.");

		ApiCommonFunctions apiCommonFunctions = new ApiCommonFunctions();
		apiCommonFunctions.loginWiIthRetailer(mobileNumber);
		String imeieNumberAfterLogin = CreateApproavedProduct.getIMEINo(mobileNumber);
		logger.info("Retailer  with mobile number "+mobileNumber+" has been loggedin.");

		if (imeieNumberAfterLogin == "0" || imeieNumberAfterLogin.length() < 15) {
			String ActualimeiNumber = "34550" + CommonMethods.getDateTimeStamp();
			System.out.println("ActualimeiNumber:"+ ActualimeiNumber);
			dbClass.updateValueInTable("client_master", "imeino", ActualimeiNumber, "mobileno", mobileNumber);
			new CreateApproavedProduct();
			CreateApproavedProduct.insertAPIKey(mobileNumber);
		} 

		retailerStateID = CreateApproavedProduct.getStateID(mobileNumber);
		quantity = data.get(0).get("Qty");
		if (PropertyFileReader.GetValue("apiCall").equalsIgnoreCase("newAPI")){
		orderNumber = apiCommonFunctions.orderPunchNewApi(data, mobileNumber, productDetailsMap);}
		else{
			orderNumber = apiCommonFunctions.generateOrderAndVerify(data, mobileNumber, productDetailsMap);}
		
		pOLinkName = dbClass.getDBvalue("po_no", dbClass.createQueryWithCondition(stockPO_TableName, "order_id",
				orderNumber.substring(orderNumber.length() - 6)));
		
		logger.info("Order number of retailer is "+orderNumber+"");
		testResult.setOrderNumber(orderNumber);
	}

	@Given("^the fpo inventory of the product is$")
	public void the_fpo_inventory_of_the_product_is(DataTable table) throws Exception {
		data = table.asMaps(String.class, String.class);
		fpoProductName = productDetailsMap.get(data.get(0).get("Name"));
		Thread.sleep(3000);

		for (int i=0;i<data.size();i++)
		{
			//
			driver.findElement(By.xpath("//a[@title='Service Provider']")).click();
			Thread.sleep(1000);
			WebElement dropDown = driver.findElement(By.className("dropdown-menu"));
			Actions action = new Actions(driver);
			WebElement dropDown1 = dropDown.findElement(By.xpath("//a[@title='Fulfillment']"));
			Thread.sleep(500);
			action.moveToElement(dropDown1).build().perform();
			Thread.sleep(1000);

			orderPage.generateFPO(productDetailsMap.get(data.get(i).get("Name")), sellerName,
					data.get(i).get("JBL INV"));
			driver.findElement(By.xpath("//a[@title='Service Provider']")).click();
			Thread.sleep(1000);
			WebElement dropDown3 = driver.findElement(By.className("dropdown-menu"));
			WebElement dropDown2 = dropDown3.findElement(By.xpath("//a[@title='Fulfillment']"));
			action.moveToElement(dropDown2).build().perform();

			orderPage.viewFPO();
			String FPONumber = driver.findElement(By.xpath("//*[@id='collated_po_table']/tbody/tr[1]/td[2]/a")).getText();
			logger.info("FPO number for product "+productDetailsMap.get(data.get(i).get("Name"))+" is "+FPONumber+"");
			System.out.println(FPONumber);
			WebElement cellProcessRTS = driver.findElement(By.xpath("//*[@id='collated_po_table']/tbody/tr[1]/td[7]"));
			cellProcessRTS.findElement(By.id("rts_submit")).click();
			
			orderPage.handleAlertPopUP("Do You Want To Process RTS For The PO :"+FPONumber+"");
			
			
			File file = new File(PropertyFileReader.GetValue("rtsImage"));
			driver.findElement(By.id("rts_form")).findElement(By.id("id_upload")).sendKeys(file.getAbsolutePath());
			driver.findElement(By.id("rts_form")).findElement(By.id("nob")).sendKeys("5");
			driver.findElement(By.id("rts_form")).findElement(By.id("upload_button")).click();
			Thread.sleep(1000);
			logger.info("RTS has been processed for FPO "+FPONumber+"");

			orderPage.processAGN(FPONumber);

			orderPage.handleAlertPopUP("AGN created successfully");
			logger.info("AGN has been done for FPO "+FPONumber+"");
			orderPage.processGRN(FPONumber);

			orderPage.handleAlertPopUP("GRN created successfully");
			logger.info("GRN has been processed for FPO "+FPONumber+"");
			String binQuantity = Integer.toString(Integer.parseInt(data.get(i).get("JBL INV"))*Integer.parseInt(data.get(i).get("Pack Of")));
			orderPage.processBinLocation(binQuantity, "FPO");

//			orderPage.handleAlertPopUP("Bin location is set");
//			Thread.sleep(1000);
//			logger.info("Bin Location has been done for FPO "+FPONumber+"");
//			driver.findElement(By.id("modal-close")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[contains(.,'COMPLETE GRN')]")).click();

			orderPage.handleAlertPopUP("GRN Complete");
			Thread.sleep(1000);
			logger.info("GRN has been completed for FPO "+FPONumber+"");
		}

	}

	@Then("^Verify the reduce warehouse quantity$")
	public void verify_Reduced_WareHouseQuantity() throws Exception {

		String NewwareHouserQuantityQuery = "SELECT * FROM `seller_warehouse_quantity` WHERE `product_id` = '"
				+ productID + "' AND `warehouse_id` = '" + wareHouseID + "'";
		String NewwareHouserQuantity = dbClass.getDBvalue("quantity", NewwareHouserQuantityQuery);
		int reducedQuantity = Integer.parseInt(wareHouserQuantity) - Integer.parseInt(quantity);
		System.out.println("reducedQuantity:" + reducedQuantity);
		Assert.assertEquals(NewwareHouserQuantity, Integer.toString(reducedQuantity));
	}

	@And("^the Total amount in PO should be$")
	public void check_Total_Amount(DataTable table) throws Exception {

		data = table.asMaps(String.class, String.class);
		Double expectedSubTotal = Double.parseDouble(dbClass.getDBvalue("subtotal", dbClass.createQueryWithCondition(stockPO_TableName,
				"order_id", orderNumber.substring(orderNumber.length() - 6))));
		Double expectedTotalTax = Double.parseDouble(dbClass.getDBvalue("total_tax_amt", dbClass.createQueryWithCondition(stockPO_TableName,
				"order_id", orderNumber.substring(orderNumber.length() - 6))));
		Double expectedGrandTotal = Double.parseDouble(dbClass.getDBvalue("total", dbClass.createQueryWithCondition(stockPO_TableName, "order_id",
				orderNumber.substring(orderNumber.length() - 6))));

		System.out.println("Sub Total Amount in db:" + expectedSubTotal);
		System.out.println("Sub Total Amount in cucumber: "+Double.parseDouble(data.get(0).get("SubTotal")));
		System.out.println("Total Tax Amount in db:"+ expectedTotalTax);
		System.out.println("Total Tax Amount in cucumber: "+Double.parseDouble(data.get(0).get("Total Tax Amt")));
		System.out.println("Grand Total Amount in db: " + expectedGrandTotal);
		System.out.println("Grand Total Amount in cucumber: "+ Double.parseDouble(data.get(0).get("Grand Total")));

        logger.info("Verify the subtotal, tax and grand total for the PO of order.");
		Assert.assertEquals(CommonMethods.almostEqual(expectedSubTotal,Double.parseDouble(data.get(0).get("SubTotal")),0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(expectedTotalTax,Double.parseDouble(data.get(0).get("Total Tax Amt")),0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(expectedGrandTotal,Double.parseDouble(data.get(0).get("Grand Total")),0.5),true);
	}

	@And("^the Retailer invoice calculation shoud be correct$")
	public void check_Retailer_Invoice(DataTable table) throws Exception {

		data = table.asMaps(String.class, String.class);

		System.out.println("retailerName:"+ retailerName);
		Assert.assertEquals(
				dbClass.getDBvalue("subtotal",
						"SELECT * FROM `retailer_invoice` WHERE `invoice_no` = '" + retailerName + "'"),
				data.get(0).get("subTotal"));
		Assert.assertEquals(
				dbClass.getDBvalue("total_tax_amt",
						"SELECT * FROM `retailer_invoice` WHERE `invoice_no` = '" + retailerName + "'"),
				data.get(0).get("total_taxt_amt"));
		Assert.assertEquals(
				dbClass.getDBvalue("total",
						"SELECT * FROM `retailer_invoice` WHERE `invoice_no` = '" + retailerName + "'"),
				data.get(0).get("total_amount"));
	}

	@Then("^the order should be placed in SCM$")
	public void check_OrderNumber_SCM() throws Exception {
		orderPage.navigateSearchOrder();
		Thread.sleep(2000);
		orderPage.searchOrederID(orderNumber);
		Assert.assertTrue(orderPage.verifyOrderInResultList(orderNumber));
		orderPage.clickViewDetailBtn();
		Thread.sleep(2000);
		Assert.assertTrue(orderPage.verifyOrderNoInOrderInfoTable(orderNumber));
	}

	@And("^the PO should be generated$")
	public void checkPO() {
		WebElement POLink = driver.findElement(By.partialLinkText(pOLinkName));
		if(POLink.isDisplayed()){logger.info("PO link is displayin for the generated order.");}
		else{logger.error("PO link is not displaying for the genrated order.");}
		Assert.assertEquals(true, POLink.isDisplayed());
	}

	@And("^the picklist should be generated$")
	public void checkOrderPicklist() throws Exception {
		pickListname = dbClass.getDBvalue("picklist_no", dbClass.createQueryWithCondition(jbl_Picklist, "order_id",
				orderNumber.substring(orderNumber.length() - 6)));
		orderPage.navigatesToPendingLMPage();
		Assert.assertEquals(true, orderPage.searchForPicklist(pickListname));
	}

	@When("^the picklist is processed completely$")
	public void processPicklist() throws Exception {
		String qty = "5";

		productID = dbClass.getDBvalue("id","SELECT * FROM `seller_product` WHERE `product_name` = '" + fpoProductName + "'");
		
		WebElement table = driver.findElement(By.xpath("//*[@id='picklist_product_list']/tbody/tr[1]/td[7]"));
		WebElement txtBox_PickedQty = table.findElement(By.xpath("//input[@data-ordered_pid='" + productID + "']"));
		String PurchasedProductQuantity = "100";//Integer.toString(Integer.parseInt(buyPackOf)*Integer.parseInt(buyQuantity));
		txtBox_PickedQty.sendKeys(PurchasedProductQuantity);
		orderPage.clickOnSubmitButton();
		//driver.switchTo().alert().accept();
		orderPage.handleAlertPopUP("Do You Really Want To Generate Retailer Invoice PickList? ");
		Thread.sleep(2000);
	}

	@When("^the Ordered direct picklist processed completely$")
	public void process_Ordered_Picklist() throws Exception {


		WebElement tableElement = driver.findElement(By.xpath("//*[@id='picklist_product_list']"));
		ArrayList<HashMap<String, WebElement>> tableData = orderPage.getDataFromTable(tableElement);
		int numberOfProduct = driver.findElements(By.xpath("//*[@id='picklist_product_list']/tbody/tr")).size();
		System.out.println(numberOfProduct);
		for (int i=1;i<=numberOfProduct;i++)
		{		
			WebElement picketQtyObj = tableData.get(i).get("Qty/Pcs");
			picketQtyObj.click();
			picketQtyObj.sendKeys(Keys.TAB+picketQtyObj.getText());
	 	}
		
		orderPage.clickOnSubmitButton();
		orderPage.handleAlertPopUP("Do You Really Want To Generate Retailer Invoice PickList? ");
		Thread.sleep(2000);
	}

	@Then("^the Retailer Invoice should be generated$")
	public void checkRetailerInvoice() throws Exception {
		retailerName = dbClass.getDBvalue("invoice_no", dbClass.createQueryWithCondition(retailer_invoice, "order_id",
				orderNumber.substring(orderNumber.length() - 6)));
		orderPage.verifyRetailerInvoiceForPicklist(pickListname,retailerName);
		logger.info("Created invoice number is displayed on pending LMD page for respective picklist.");
		//Assert.assertEquals(true, orderPage.searchForPicklistRetailerInvoice(pickListname, retailerName));
	}

	@And("^picklist calculation should be correct$")
	public void checkPicklistCalculation() throws InterruptedException {
		orderPage.clickOnPicklist(pickListname);
		//orderPage.verifyProductUnderPicklistProductTable(productID, "1");
	}

	@Given("^update table$")
	public void updateTable() throws Exception {
		dbClass.updateTable("quantity", "501", "id", "223960");
	}

	@Then("^Verify the reduce warehouse quantity is \"(.*?)\"$")
	public void verify_the_reduce_warehouse_quantity_is(String expected_WarehouseQuantity) throws Exception {
		System.out.println("productID:" + productID);

		String wareHouserQuantityQuery = "SELECT * FROM `seller_warehouse_quantity` WHERE `product_id` = '" + productID
				+ "'";
		String actual_WareHouserQuantity = dbClass.getDBvalue("quantity", wareHouserQuantityQuery);
		Assert.assertEquals(actual_WareHouserQuantity, expected_WarehouseQuantity);
	}

	@Then("^Verify the reduce warehouse quantity of \"(.*?)\" is \"(.*?)\"$")
	public void verify_the_reduce_warehouse_quantity_of_is(String productName, String quantity) throws Throwable {

		String expectedProductName = productDetailsMap.get(productName);
		productID = dbClass.getDBvalue("id","SELECT * FROM `seller_product` WHERE `product_name` = '" + expectedProductName + "'");
		String wareHouserQuantityQuery = "SELECT * FROM `seller_warehouse_quantity` WHERE `product_id` = '" + productID+ "'";
		String actual_WareHouserQuantity = dbClass.getDBvalue("quantity", wareHouserQuantityQuery);
		Assert.assertEquals(actual_WareHouserQuantity, quantity);

	}

	@Then("^purchase and offered product should displayed properly in retailer invoice$")
	public void purchase_and_offered_product_should_displayed_properly_in_retailer_invoice() throws Throwable {
		driver.findElement(By.id("view_suborder")).click();
		Thread.sleep(5000);

		String actualPurchasedProduct = driver.findElement(By.xpath("//*[@id='picklist_product_list']/tbody/tr[1]/td[2]")).getText();
		Assert.assertEquals(actualPurchasedProduct, purchasedProduct);

		String actualOfferedProduct = driver.findElement(By.xpath("//*[@id='picklist_product_list']/tbody/tr[2]/td[2]")).getText();
		Assert.assertEquals(actualOfferedProduct, offeredProduct);
	}
	
	@Then("^process RTS for the PO$")
	public void waitForCPOProcessing()
	{
		
	}
	@And("^the direct picklist should be generated with following products$")
	public void verify_DirectPicklist(DataTable table) throws Exception {
		data = table.asMaps(String.class, String.class);
		String picklistName = data.get(0).get("picklist no");
		ResultSet rs = dbClass.getResultSet("jbl_picklist", "order_id", orderNumber.substring(orderNumber.length() - 6));
		Object[] picklistNumber = dbClass.getDataFromResultSet(rs, "picklist_no").toArray();
		Object[] prod_details = dbClass.getDataFromResultSet(rs, "prod_details").toArray();
		rs.close();
		boolean flag = true;

		for (int picklistCount = 0; picklistCount < picklistNumber.length; picklistCount++) {
			for (int i = 0; i < data.size(); i++) {
				if (prod_details[picklistCount].toString().contains(data.get(i).get("Name"))
						&& prod_details[i].toString().contains(data.get(i).get("pcs"))) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
			if (flag==true){
				picklistNumberMap.put(data.get(0).get("picklist no"), picklistNumber[picklistCount].toString());
				logger.info(""+picklistNumber[picklistCount].toString()+" is created for "+picklistName);
			}
		}
	}
	
	@When("^the picklist \"(.*?)\" is processed$")
	public void the_picklist_is_processed(String picklistName) throws Throwable {

		String expectedPicklistName = picklistNumberMap.get(picklistName);
		orderPage.navigatesToPendingLMPage();
		Assert.assertEquals(true, orderPage.searchForPicklist(expectedPicklistName));
		orderPage.clickOnPicklist(expectedPicklistName);
		Thread.sleep(2000);
		WebElement tableElement = driver.findElement(By.xpath("//*[@id='picklist_product_list']"));
		ArrayList<HashMap<String, WebElement>> tableData = orderPage.getDataFromTable(tableElement);
		int numberOfProduct = driver.findElements(By.xpath("//*[@id='picklist_product_list']/tbody/tr")).size();
		System.out.println(numberOfProduct);
		for (int i=1;i<=numberOfProduct;i++)
		{		
			WebElement picketQtyObj = tableData.get(i).get("Picked Qty").findElement(By.xpath("//input[@type='text'][contains(@class,'product_number')]"));
			picketQtyObj.sendKeys(tableData.get(i).get("Qty/Pcs").getText());
	 	}
		
		orderPage.clickOnSubmitButton();
		orderPage.handleAlertPopUP("Do You Really Want To Generate Retailer Invoice PickList? ");

	}

	@Then("^the retailer invoice \"(.*?)\" should be generated for picklist \"(.*?)\"$")
	public void the_retailer_invoice_should_be_generated_for_picklist(String actualRetailerInvoiceName, String actualPicklistName) throws Throwable {
		
		Thread.sleep(10000);
		String expectedPicklistName = picklistNumberMap.get(actualPicklistName);
		String expectedInvoiceNumber = dbClass.getDBvalue("invoice_no", "SELECT * FROM `retailer_invoice` WHERE `picklist_id` = (SELECT id FROM `jbl_picklist` WHERE `picklist_no` = '"+expectedPicklistName+"')");
		logger.info(""+expectedInvoiceNumber+" has been generated for picklist "+expectedPicklistName+"");
		orderPage.verifyRetailerInvoiceForPicklist(expectedPicklistName,expectedInvoiceNumber);
		logger.info("Created invoice number is displayed on pending LMD page for respective picklist.");
		retailerInvoiceMap.put(actualRetailerInvoiceName, expectedInvoiceNumber);
		picklistAndInvoiceMap.put(actualPicklistName, actualRetailerInvoiceName);
	}

	@When("^the LMD is processed and dispatched for retailer invoice \"(.*?)\"$")
	public void the_LMD_is_processed_and_dispatched_for_retailer_invoice(String actualInvoiceNumber) throws Throwable {
		
		String actualPicklistName = CommonMethods.getKeyOfMap(picklistAndInvoiceMap, actualInvoiceNumber);
		lmdPage.processPicklistLMDDetails(picklistNumberMap.get(actualPicklistName));

		orderPage.handleAlertPopUP("LMD is processed successfully.");
		Thread.sleep(2000);
		
		//LMD is processed successfully.
		lmdPage.processPendingDispatch(picklistNumberMap.get(actualPicklistName));

		orderPage.handleAlertPopUP("Confirm the material is shipping from warehouse");
		Thread.sleep(1000);
		orderPage.handleAlertPopUP("LMD status is updated to Shipped successfully");

	}

	@Then("^the retailer invoice \"(.*?)\" status should be shipped$")
	public void the_retailer_invoice_status_should_be_shipped(String actualInvoiceNumber) throws Throwable {
		String actualPicklistName = CommonMethods.getKeyOfMap(picklistAndInvoiceMap, actualInvoiceNumber);
		lmdPage.ClickOnProcessedLMDTab();
		orderPage.verifyInvoiceStatus(picklistNumberMap.get(actualPicklistName),"Shipped");
		logger.info("Retailer invoice status is displayed as shipped.");
	}

	@Then("^the retailer invoice \"(.*?)\" should contains the following products$")
	public void the_retailer_invoice_should_contains_the_following_products(String arg1, DataTable arg2) throws Throwable {

	}

	@Then("^the Retailer Invoice \"(.*?)\" calculation should be correct$")
	public void the_Retailer_Invoice_calculation_should_be_correct(String actualInvoiceNumber, DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		
		ResultSet rs = dbClass.getResultSet("retailer_invoice", "invoice_no", retailerInvoiceMap.get(actualInvoiceNumber));
		String expectedSubTotal = dbClass.getSingleValueFromResultSet(rs, "subtotal");
		String TotalTaxAmount = dbClass.getSingleValueFromResultSet(rs, "total_tax_amt");
		String expectedTotal = dbClass.getSingleValueFromResultSet(rs, "total");
		rs.close();
		
		Assert.assertEquals(CommonMethods.almostEqual(Double.parseDouble(expectedSubTotal),Double.parseDouble(data.get(0).get("subTotal")),0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(Double.parseDouble(TotalTaxAmount),Double.parseDouble(data.get(0).get("total_taxt_amt")),0.5),true);
		Assert.assertEquals(CommonMethods.almostEqual(Double.parseDouble(expectedTotal),Double.parseDouble(data.get(0).get("total_amount")),0.5),true);
	}

	@When("^brand process RTS for PO$")
	public void brand_process_RTS_for_PO(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		
		//Open the order page.
		orderPage.navigateSearchOrder();
		Thread.sleep(3000);
		orderPage.searchOrederID(orderNumber);
		Assert.assertTrue(orderPage.verifyOrderInResultList(orderNumber));
		orderPage.clickViewDetailBtn();
		Thread.sleep(2000);
		
		orderPage.clickOnILPProcessingTab();
		WebElement tableElement = driver.findElement(By.xpath(".//*[@id='content2']//table"));
		ArrayList<HashMap<String, WebElement>> tableData = orderPage.getDataFromTable(tableElement);
		String[] POArray = new String[20];
				System.out.println("tableData.size():"+ tableData.size());
		for (int i=1;i<tableData.size();i++){
			POArray[i-1] = tableData.get(i).get("PO/CPO No.").getText();
			dbClass.updateValueInTable("stock_po", "is_ready_to_ship", "1", "po_no",POArray[i-1]);
			POMap.put(data.get(i-1).get("Po No"), POArray[i-1]);
			logger.info("RTS value has been set as 1 in stock po table for po "+POArray[i-1]+"");
		}
		Thread.sleep(180000);
		driver.navigate().refresh();
		Thread.sleep(2000);
		orderPage.clickOnILPProcessingTab();
		WebElement tableElement2 = driver.findElement(By.xpath(".//*[@id='content2']//table"));
		ArrayList<HashMap<String, WebElement>> tableData2 = orderPage.getDataFromTable(tableElement2);
		
		for (int i=1;i<tableData2.size();i++)
		{
		  WebElement orderTrackingObj = tableData2.get(i).get("ILP Airway No.").findElement(By.xpath("//a[@title='Order Tracking']"));
		  Assert.assertEquals(true, orderTrackingObj.isDisplayed());
		}
	}
	
	@Then("^brand process RTS for PO of order$")
	public void process_RTS_PO_For_Order() throws Exception
	{
		dbClass.updateValueInTable("stock_po", "is_ready_to_ship", "1", "po_no",pOLinkName);
		logger.info("RTS value has been set as 1 in stock po table for po "+pOLinkName+"");
	}

	/*@When("^the warehouse incharge does AGN and GRN for PO \"(.*?)\"$")
	public void the_warehouse_incharge_does_AGN_and_GRN_for_PO(String actualPONumber) throws Throwable {
		String expectedPONumber = POMap.get(actualPONumber);
		orderPage.processAGN(expectedPONumber);

		orderPage.handleAlertPopUP("AGN created successfully");
		logger.info("AGN has been done for PO "+actualPONumber+"");
		orderPage.processGRN(expectedPONumber);

		orderPage.handleAlertPopUP("GRN created successfully");
		logger.info("GRN has been processed for PO "+actualPONumber+"");
		
		String getReceivedQuantity = "1";
		orderPage.processBinLocation(getReceivedQuantity, "PO");

		orderPage.handleAlertPopUP("Bin location is set");
		Thread.sleep(1000);
		logger.info("Bin Location has been done for PO "+actualPONumber+"");
		driver.findElement(By.id("modal-close")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[contains(.,'COMPLETE GRN')]")).click();

		orderPage.handleAlertPopUP("GRN Complete");
		Thread.sleep(1000);
		logger.info("GRN has been completed for PO "+actualPONumber+"");
	 
	}*/
	
	@When("^the warehouse incharge does AGN and GRN$")
	public void the_warehouse_incharge_does_AGN_and_GRN_for_PO(DataTable table) throws Throwable {
		System.out.println( " in agn grn process ============= "+POMap);
		data = table.asMaps(String.class, String.class);
		for (int i=0;i<data.size();i++)
		{
			String actualPONumber=data.get(i).get("Po No");
			String expectedPONumber = POMap.get(actualPONumber);
			System.out.println("=========================================  "+expectedPONumber);
			if (expectedPONumber!=null){
				orderPage.processAGN(expectedPONumber);
				orderPage.handleAlertPopUP("AGN created successfully");
				logger.info("AGN has been done for PO "+actualPONumber+"");
				
				orderPage.processGRN(expectedPONumber);
				orderPage.handleAlertPopUP("GRN created successfully");
				logger.info("GRN has been processed for PO "+actualPONumber+"");
				
				String getReceivedQuantity = "0";
				orderPage.processBinLocation(getReceivedQuantity,"PO");
				
				Thread.sleep(2000);
				driver.findElement(By.xpath("(//button[@type='button'])[2]")).click();
				orderPage.handleAlertPopUP("GRN Complete");
				Thread.sleep(1000);
				logger.info("GRN has been completed for PO "+actualPONumber+"");
		   }
		}
	}
	
	

	@When("^the picklist should be generated for \"(.*?)\"$")
	public void the_picklist_should_be_generated_for(String actualPONumber, DataTable table) throws Throwable {
	
		data = table.asMaps(String.class, String.class);
		String picklistName = data.get(0).get("picklist no");
		ResultSet rs = dbClass.getResultSet("jbl_picklist", "order_id", orderNumber.substring(orderNumber.length() - 6));
		Object[] picklistNumber = dbClass.getDataFromResultSet(rs, "picklist_no").toArray();
		Object[] prod_details = dbClass.getDataFromResultSet(rs, "prod_details").toArray();
		rs.close();
		boolean flag = true;

		for (int picklistCount = 0; picklistCount < picklistNumber.length; picklistCount++) {
			for (int i = 0; i < data.size(); i++) {
				if (prod_details[picklistCount].toString().contains(data.get(i).get("Name"))
						&& prod_details[i].toString().contains(data.get(i).get("pcs"))) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
			if (flag==true){
				picklistNumberMap.put(data.get(0).get("picklist no"), picklistNumber[picklistCount].toString());
				
			}
		}
	}

	@Then("^the Retailer invoice \"(.*?)\" calculation shoud be correct$")
	public void the_Retailer_invoice_calculation_shoud_be_correct(String arg1, DataTable arg2) throws Throwable {

	}

	@When("^the retailer returns an order for$")
	public void the_retailer_returns_an_order_for(DataTable table) throws Throwable {

		data = table.asMaps(String.class, String.class);
		for (int i=0;i<retailerInvoiceMap.size();i++)
		{
			driver.findElement(By.xpath("//a[@title='Service Provider']")).click();
			Thread.sleep(500);
			driver.findElement(By.xpath("//a[contains(.,'LMD LSP Tracker')]")).click();
			Thread.sleep(500);
			lmdPage.processLMDTracker(retailerInvoiceMap.get(data.get(i).get("invoice no")));

			orderPage.handleAlertPopUP("Do you want to update the LMD details of the retailer invoice order");
			Thread.sleep(1000);
			orderPage.handleAlertPopUP("Order has updated successfully");

		}
	
	}

	@When("^the sales return is recieved for the invoice$")
	public void the_sales_return_is_recieved_for_the_invoice(DataTable table) throws Throwable {
          
		data = table.asMaps(String.class, String.class);
		lmdPage.navigateToSalesReturnRecieved();
		for (int i=0;i<retailerInvoiceMap.size();i++)
		{
		     lmdPage.processSalesReturnRecived(retailerInvoiceMap.get(data.get(i).get("invoice no")));
		     orderPage.handleAlertPopUP("AGN created successfully");
		     logger.info("AGN has been processed for retailer invoice "+retailerInvoiceMap.get(data.get(i).get("invoice no"))+"");
		}
	
	}

	@When("^the sales return is inbounded for the invoice$")
	public void the_sales_return_is_inbounded_for_the_invoice(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		lmdPage.navigateToSalesReturnInboundTab();
		for (int i=0;i<retailerInvoiceMap.size();i++)
		{
		     lmdPage.processSalesReturnInbound(retailerInvoiceMap.get(data.get(i).get("invoice no")));
		     orderPage.handleAlertPopUP("GRN created successfully");
		     logger.info("GRN has been processed for retailer invoice "+retailerInvoiceMap.get(data.get(i).get("invoice no"))+"");
		     
		     lmdPage.processBinLocation(data.get(i).get("bin Location"));
		     orderPage.handleAlertPopUP("Bin location is set");
		     logger.info("GRN has been processed for retailer invoice "+retailerInvoiceMap.get(data.get(i).get("invoice no"))+"");
		     Thread.sleep(1000);
		     driver.findElement(By.id("modal-close")).click();
			 Thread.sleep(1000);
			 
			 driver.findElement(By.xpath("//button[contains(.,'COMPLETE GRN')]")).click();
			 orderPage.handleAlertPopUP("RTO GRN Complete");
			 logger.info("GRN has been Completed for retailer invoice "+retailerInvoiceMap.get(data.get(i).get("invoice no"))+"");
			 Thread.sleep(2000);
		}
	}

	@When("^the product inventory should be updated in database as$")
	public void the_product_inventory_should_be_updated_in_database_as(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		
		for (int i=0;i<data.size();i++)
		{
			String productID = dbClass.getDBvalue("id","SELECT * FROM `seller_product` WHERE `product_name` = '" + productDetailsMap.get(data.get(i).get("Name")) + "'");
			String JitQty = dbClass.getDBvalue("quantity","SELECT * FROM `seller_warehouse_quantity` WHERE `product_id` = '"+productID+"'");
			Assert.assertEquals(JitQty, data.get(i).get("JIT INV"));
			
			String jblInv = dbClass.getDBvalue("fpo_quantity","SELECT * FROM `jbl_inventory` WHERE `seller_product_id` = '"+productID+"' AND `fc_code` = 'JBL01'");
			Assert.assertEquals(jblInv, data.get(i).get("JBL INV"));
			
			String rtoInv = dbClass.getDBvalue("rto_quantity","SELECT * FROM `jbl_inventory` WHERE `seller_product_id` = '"+productID+"' AND `fc_code` = 'JBL01'");
			Assert.assertEquals(rtoInv, data.get(i).get("RTO INV"));
	
		}
	}
	
	@Given("^the PO should be generated for all sellers$")
	public void verify_PO_For_All_Seller() throws Exception
	{
		 ResultSet rs = dbClass.getResultSet("stock_po", "order_id", orderNumber.substring(orderNumber.length() - 6));
		 ArrayList<String> arrayList_PO =  dbClass.getDataFromResultSet(rs, "po_no");
		 ArrayList<String> arrayList_Seller =  dbClass.getDataFromResultSet(rs, "seller_id");
		 rs.close(); 
		 for (int i=0;i<arrayList_Seller.toArray().length;i++)
		 {
		     String expectedSellerName = dbClass.getSingleData("seller_name", "seller_master", "id", arrayList_Seller.toArray()[i].toString());
		     System.out.println(expectedSellerName);
		     System.out.println(arrayList_PO.toArray()[i].toString());
		     sellerPOMap.put(expectedSellerName, arrayList_PO.toArray()[i].toString());
		 }
         testResult.setPOMap(sellerPOMap);
		 WebElement tableElement = driver.findElement(By.xpath("//table[@class='table table-striped']"));
		 ArrayList<HashMap<String, WebElement>> tableData = orderPage.getDataFromTable(tableElement);
		 
		 for (int i=1;i<tableData.size();i++){
			 System.out.println(sellerPOMap.get(tableData.get(i).get("Seller Name").getText()));	
			 System.out.println(tableData.get(i).get("PO No.").getText());
			 Assert.assertEquals(sellerPOMap.get(tableData.get(i).get("Seller Name").getText().trim()), tableData.get(i).get("PO No.").getText().trim());
		}
	}
	
	@Given("^Po calculation for all PO should be correct$")
	public void verify_PO_CalculationFor_PO() throws NumberFormatException, Exception
	{
		Object[] productName;
		for (Map.Entry<String, String> entry : sellerPOMap.entrySet()) {
			String key = entry.getKey();
			productName = sellerProductMap.get(key).toArray();	
			CommonMethods.verifyPOCalculation(productListMap,orderProductmap,productName,sellerPOMap.get(key),retailerStateID);
		}
	}
	
	/*====================================================datta's changes=============================================================*/
	
	@Then("^Verify ILP process should be completed and AWB no shuld be generated for PO$")
	public void verifyIlp(DataTable table) throws Throwable
	{
		System.out.println("*******************************aiting start************************************");
		//Thread.sleep(240000);
		System.out.println("*******************************aiting end************************************");
		data = table.asMaps(String.class, String.class);
		System.out.println("=======================in ilp verification=====================");
		driver.navigate().refresh();
		driver.findElement(By.xpath("//a[contains(text(),'Order History')]")).click();
		driver.findElement(By.id("searchi")).sendKeys(orderNumber);
		driver.findElement(By.id("searching")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("viewdetails")).click();
		Thread.sleep(2000);
		orderPage.clickOnILPProcessingTab();
		WebElement tableElement2 = driver.findElement(By.xpath(".//*[@id='content2']//table"));
		ArrayList<HashMap<String, WebElement>> tableData2 = orderPage.getDataFromTable(tableElement2);
		
		for (int i=1;i<tableData2.size();i++)
		{
		  String expectedPO = tableData2.get(i).get("PO/CPO No.").getText();
		  WebElement orderTrackingObj = tableData2.get(i).get("ILP Airway No.").findElement(By.linkText("Order Tracking"));
		  String awbNo = tableData2.get(i).get("ILP Airway No.").getText();
		  awbNo = awbNo.substring(0,awbNo.indexOf(" "));
		  String ilpby  = tableData2.get(i).get("ILP Service By").getText();
		  System.out.println("=================================================================");
		  Assert.assertEquals(true, orderTrackingObj.isDisplayed());
		  //testResult.setawbNo(awbNo);
		  //testResult.setilpby(ilpby);
		  POMap.put(data.get(i-1).get("Po No"), expectedPO);
		  System.out.println(POMap);
		  System.out.println("ilp id done by "+ilpby+" and awb no is "+awbNo);
		}
	}
	@When("^the picklist is processed$")
	public void the_picklist_is_processed(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		Map<String, String> PicklistMap = new HashMap<String, String>();
		orderPage.navigatesToPendingLMPage();
		driver.findElement(By.id("order_no")).sendKeys(orderNumber);
		driver.findElement(By.id("search_button")).click();
		WebElement tableElement2 = driver.findElement(By.xpath(".//table[@class='table']"));
		
		ArrayList<HashMap<String, WebElement>> tableData2 = orderPage.getDataFromTable(tableElement2);
		System.out.println(tableData2.size() +"=========");
		
		for (int i=1;i<tableData2.size();i++)
		{
		  String picklist = tableData2.get(i).get("PICKLIST NO.").getText();
		  String picklistName = data.get(i-1).get("picklistName");
		  System.out.println("================================================================="+picklistName);
		  picklistNumberMap.put(data.get(i-1).get("picklistName"), picklist);
		  System.out.println(picklistNumberMap);
		}
		System.out.println("there are "+picklistNumberMap.size()+" picklist for order");
		try
		{
			for(int i=0;i<picklistNumberMap.size();i++)
			{
				try
				{
					driver.findElement(By.linkText("GRN")).click();
					driver.findElement(By.linkText("LMD")).click();
					driver.findElement(By.linkText("Pending LMD")).click();
					String picklistNo = picklistNumberMap.get(data.get(i).get("picklistName"));	
					Thread.sleep(2000);
						driver.findElement(By.id("picklist_no")).sendKeys(picklistNo);
						driver.findElement(By.id("search_button")).click();
						driver.findElement(By.linkText(picklistNo)).click();
						Thread.sleep(2000);
						WebElement tableElement = driver.findElement(By.xpath("//*[@id='picklist_product_list']"));
						List<WebElement> products = tableElement.findElements(By.tagName("tr"));
						System.out.println("for picklist "+picklistNo+" there are "+products.size()+" products");
					
					
					for (int j=1;j<products.size();j++)
					{
						String Qty = products.get(j).findElement(By.xpath("//table[@id='picklist_product_list']/tbody/tr["+j+"]/td[4]")).getText();
						System.out.println(Qty);
						products.get(j).findElement(By.tagName("input")).sendKeys(Qty);
					}
					orderPage.clickOnSubmitButton();
					orderPage.handleAlertPopUP("Do You Really Want To Generate Retailer Invoice PickList? ");
					Thread.sleep(2000);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					driver.navigate().back();
					tableData2 = orderPage.getDataFromTable(tableElement2);
					System.out.println(tableData2 +"=========");
					
					for (int k=1;k<tableData2.size();k++)
					{
					  String picklist = tableData2.get(k).get("PICKLIST NO.").getText();
					  System.out.println("=================================================================");
					  picklistNumberMap.put(data.get(k-1).get("picklistName"), picklist);
					  System.out.println(picklistNumberMap);
					}
				}
				
			}
		}
		catch(Exception e)
		{
			System.out.println("error while processing picklist");
			e.printStackTrace();
		}
		
		System.out.println("************************************************************************************************");
		}
	@Then("^Verify Retailer invoice is generated for picklist$")
	public void the_retailer_invoice_should_be_generated_for_picklist(DataTable table) throws Throwable {
		Thread.sleep(10000);
		data = table.asMaps(String.class, String.class);
		for(int i=0;i<data.size();i++)
		{
			String actualRetailerInvoiceName = data.get(i).get("retailerInvoice");
			String actualPicklistName = data.get(i).get("picklistName");
			String expectedPicklistName = picklistNumberMap.get(actualPicklistName);
			if (expectedPicklistName!=null){
				String expectedInvoiceNumber = dbClass.getDBvalue("invoice_no", "SELECT * FROM `retailer_invoice` WHERE `picklist_id` = (SELECT id FROM `jbl_picklist` WHERE `picklist_no` = '"+expectedPicklistName+"')");
				logger.info(""+expectedInvoiceNumber+" has been generated for picklist "+expectedPicklistName+"");
				orderPage.verifyRetailerInvoiceForPicklist(expectedPicklistName,expectedInvoiceNumber);
				logger.info("Created invoice number is displayed on pending LMD page for respective picklist.");
				retailerInvoiceMap.put(actualRetailerInvoiceName, expectedInvoiceNumber);
				picklistAndInvoiceMap.put(actualPicklistName, actualRetailerInvoiceName);
			}	
		}

	}
	@Given("^Process RTS of below offered order and Verify ILP$")
	public void process_RTS_of_all_offered_order(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		for (int i=0;i<data.size();i++){
			String expectedOrderNumber = CommonMethods.getCellData(data.get(i).get("Scenarioname"), "Order Number");
			System.out.println("expectedOrderNumber:"+expectedOrderNumber);
			String expectedPO = dbClass.getSingleData("po_no", stockPO_TableName, "order_id", expectedOrderNumber.substring(expectedOrderNumber.length() - 6));
            String execuionStatus = CommonMethods.getCellData(data.get(i).get("Scenarioname"), "Execution Status");
            if (execuionStatus.equalsIgnoreCase("passed")){
            	dbClass.updateValueInTable("stock_po", "is_ready_to_ship", "1", "po_no",expectedPO);
            	POMap.put(data.get(i).get("Po No"), expectedPO);
            	logger.info("RTS value has been set as 1 in stock po table for scenario "+data.get(i).get("Scenarioname")+"");
            }
		}
		Thread.sleep(180000);
		for (int i=0;i<data.size();i++){
			String expectedOrderNumber = CommonMethods.getCellData(data.get(i).get("Scenarioname"), "Order Number");
			String execuionStatus = CommonMethods.getCellData(data.get(i).get("Scenarioname"), "Execution Status");
            if (execuionStatus.equalsIgnoreCase("passed")){
				orderPage.navigateSearchOrder();
				Thread.sleep(2000);
				orderPage.searchOrederID(expectedOrderNumber);
				Assert.assertTrue(orderPage.verifyOrderInResultList(expectedOrderNumber));
				orderPage.clickViewDetailBtn();
				Thread.sleep(2000);
				Assert.assertTrue(orderPage.verifyOrderNoInOrderInfoTable(expectedOrderNumber));
				orderPage.clickOnILPProcessingTab();
				WebElement tableElement2 = driver.findElement(By.xpath(".//*[@id='content2']//table"));
				WebElement orderTrackingObj = tableElement2.findElement(By.linkText("Order Tracking"));
				Assert.assertEquals(true, orderTrackingObj.isDisplayed());
        }
	}
}
	@When("^the picklist is processed for every PO$")
	public void picklist_processed_for_PO(DataTable table) throws Throwable {
		data = table.asMaps(String.class, String.class);
		
		for (int i=0;i<data.size();i++){
		String expectedPOName = POMap.get(data.get(i).get("Po No"));
		if (expectedPOName!=null){
				orderPage.navigatesToPendingLMPage();
				Assert.assertEquals(true, orderPage.searchForPO(expectedPOName));
				WebElement tableElement = driver.findElement(By.id("order_table"));
				ArrayList<HashMap<String, WebElement>> tableData = orderPage.getDataFromTable(tableElement);
				picklistNumberMap.put(data.get(i).get("picklistName"), tableData.get(1).get("PICKLIST NO.").getText());
				orderPage.clickOnPicklist(picklistNumberMap.get(data.get(i).get("picklistName")));
				Thread.sleep(2000);
				WebElement tableElement1 = driver.findElement(By.xpath("//*[@id='picklist_product_list']"));
				ArrayList<HashMap<String, WebElement>> tableData2 = orderPage.getDataFromTable(tableElement1);
				int numberOfProduct = driver.findElements(By.xpath("//*[@id='picklist_product_list']/tbody/tr")).size();
				System.out.println(numberOfProduct);
				for (int j=1;j<=numberOfProduct;j++)
				{		
					WebElement picketQtyObj = tableData2.get(j).get("Qty/Pcs");
					picketQtyObj.click();
					picketQtyObj.sendKeys(Keys.TAB+picketQtyObj.getText());
			 	}
			
			    orderPage.clickOnSubmitButton();
			    orderPage.handleAlertPopUP("Do You Really Want To Generate Retailer Invoice PickList? ");
	       }
		}
	}
	@When("^stock movement is done for product from bin1 to bin2$")
	public void binMovement(DataTable table) throws InterruptedException {
		
		data = table.asMaps(String.class, String.class);
		for(int i=0;i<data.size();i++)
		{
		String fromBinid = data.get(i).get("fromBin");
		String toBinId = data.get(i).get("toBin");
		String product = productDetailsMap.get(data.get(i).get("Name"));
		System.out.println("********************************** "+product);
		driver.findElement(By.linkText("JBL Warehouse Management")).click();
		driver.findElement(By.linkText("Bin Movement")).click();
		driver.findElement(By.xpath("//button[@value='Create']")).click();
		WebElement warehouseName = driver.findElement(By.xpath("//td[2]/div/div/button"));
		warehouseName.click();
		WebElement warehouseNameoptions = driver.findElement(By.xpath(".//div[@class='dropdown-menu open']"));
		warehouseNameoptions.findElement(By.xpath("//input[@type='text']")).sendKeys("JBL01"+Keys.ENTER);
		
		
		WebElement fromBin = driver.findElement(By.xpath("//div[@class='btn-group bootstrap-select from_bin_location with-ajax']"));
		fromBin.click();
		Thread.sleep(500);
		List<WebElement> fromBinOptions = fromBin.findElements(By.xpath("//input[@class='input-block-level form-control'][@type='text']"));
		fromBinOptions.get(1).click();
		fromBinOptions.get(1).sendKeys("");
		fromBinOptions.get(1).sendKeys(fromBinid+Keys.ENTER);
		
		WebElement toBin = driver.findElement(By.xpath("//div[@class='btn-group bootstrap-select to_bin_location with-ajax']"));
		toBin.click();
		Thread.sleep(500);
		List<WebElement> toBinOptions = fromBin.findElements(By.xpath("//input[@class='input-block-level form-control'][@type='text']"));
		toBinOptions.get(2).click();
		toBinOptions.get(2).sendKeys("");
		toBinOptions.get(2).sendKeys(toBinId);
		toBinOptions.get(2).sendKeys(" ");
		toBinOptions.get(2).sendKeys(Keys.ENTER);
		
		WebElement productName = driver.findElement(By.xpath("//div[@class='btn-group bootstrap-select product_list with-ajax']"));
		productName.click();
		List<WebElement> productOptions = fromBin.findElements(By.xpath("//input[@class='input-block-level form-control'][@type='text']"));
		toBinOptions.get(3).click();
		toBinOptions.get(3).sendKeys(product);
		Thread.sleep(1000);
		toBinOptions.get(3).sendKeys(" ");
		Thread.sleep(1000);
		toBinOptions.get(3).sendKeys(Keys.ENTER);
		driver.findElement(By.id("productqty")).sendKeys(data.get(i).get("moveqty"));
		driver.findElement(By.id("add_submit")).click();
		orderPage.handleAlertPopUP("You want to proceed.");
		orderPage.handleAlertPopUP("Bin Movement picklist created.");
		driver.findElement(By.id("confirm_button")).click();
		orderPage.handleAlertPopUP("Bin Movement putaway details updated successfully.");
		}
		}
	
	@Then("^verify product stock must be displayed correctly on both location$")
	public void verifyBinQty(DataTable table) throws Throwable 
	{
			data = table.asMaps(String.class, String.class);
			for (int i = 0; i < data.size(); i++) 
			{
				
				String fromBin = data.get(i).get("Bin");
				String actualProductName = productDetailsMap.get(data.get(i).get("Name"));
				productID = dbClass.getDBvalue("id",
						"SELECT * FROM `seller_product` WHERE `product_name` = '" + actualProductName + "'");
				
				String BinInwordQty = dbClass.getDBvalue("inward_qty","select * from tbl_scm_bin_inventory where product_id="+productID+" and bin_location_code like '%-"+fromBin+"-%'");
				String BinOutwardQty = dbClass.getDBvalue("outward_qty","select * from tbl_scm_bin_inventory where product_id="+productID+" and bin_location_code like '%-"+fromBin+"-%'");
				String BinActualQty = dbClass.getDBvalue("actual_qty","select * from tbl_scm_bin_inventory where product_id="+productID+" and bin_location_code like '%-"+fromBin+"-%'");
	
				System.out.println(fromBin +" | "+BinInwordQty+" | "+BinOutwardQty+" | "+BinActualQty);
				
				Assert.assertEquals(data.get(i).get("inwardQty").toString(),BinInwordQty);
				Assert.assertEquals(data.get(i).get("outwardQty").toString(),BinOutwardQty);
				Assert.assertEquals(data.get(i).get("actualQty").toString(),BinActualQty);
				
			}
	}
		
	
}