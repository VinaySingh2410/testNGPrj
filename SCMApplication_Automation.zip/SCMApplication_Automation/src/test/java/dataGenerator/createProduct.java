package dataGenerator;

public class createProduct {
	
public String createTestProduct(String prdName, String rto, String fpo, String jit,String sellerName, String mrp, String dp, String JBLMargin, String taxType,String brandName, String isFree, String packOf) throws Exception{
		//SellerDetails sellerDetails1 = new SellerDetails();
		//System.out.println(sellerDetails1);
		productDetails details = new productDetails();
		details.ProductName = prdName;
		
		if (rto!=null) {details.rtoQty = Integer.parseInt(rto);} else {details.rtoQty =0;}
		if (fpo!=null){details.fpoQty = Integer.parseInt(fpo);}else {details.fpoQty =0;}
   		if(jit!=null){details.jitQty = Integer.parseInt(jit);}else {details.jitQty =0;}
	    details.SellerName = sellerName;
	    if (mrp!=null){details.MRP = Double.parseDouble(mrp);} 
	    if (dp!=null){details.dealerPrice = Double.parseDouble(dp);}
	    if (JBLMargin!=null){details.dealerMargin=Double.parseDouble(JBLMargin);}
	    if (taxType!=null){details.taxType = taxType;}
	    if (brandName!=null){details.BrandName = brandName;}
	    if (isFree!=null){details.isFreeProduct = isFree;}
	    if (packOf!=null){details.packOf = packOf;}
	    
	    
	    
	    System.out.println("String:"+ details.getString());
		new CreateApproavedProduct().productDetails(details.getString());
		String prodName123 = CreateApproavedProduct.getProductName();
		System.out.println("Newly Created Product Name is:"+prodName123);
		
		return prodName123;
	
		
	}
}
