package dataGenerator;

public class SellerDetails {
	public String sellerName="TestDataShamimSeller";
	public int stateId=21;
	public String cityId="389";
	public String pincodeId="81444";
	public String isCPO="N";
	public int CSTBilling=0;
	public String WarehouseCode="WH001";
	public String isITC="0";
	
	public String getString(){
		String str = "Seller Name=" + sellerName
				+",Seller State Id=" + stateId
				+",Seller City Id=" + cityId
				+",Seller Pincode Id=" + pincodeId
				+",is CPO=" + isCPO
				+",CST Billing=" + CSTBilling
				+",Warehouse Code=" + WarehouseCode
				+",IS ITC=" + isITC;
		
		return str;
	}
	
}
