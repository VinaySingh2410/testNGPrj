package dataGenerator;

import org.testng.annotations.Test;


public class Offer {
	public void addOfferToProduct(String SellerName, String brandName, String productName, 
			String freeProductName, String freeProductQuantity,String offerDiscountType, String offerDiscountValue,
			String offerProductQuantity, String offerID,String discountDetailsType) throws Exception{
		
		OfferDetails details = new OfferDetails();
		
		if (brandName!=null){details.brandName = brandName;}
		if (SellerName!=null){details.SellerName =SellerName;}
		if (productName!=null){details.productName =productName;}
		if (freeProductName!=null){details.freeProductName =freeProductName;}
		if (freeProductQuantity!=null){details.freeProductQuantity = Integer.parseInt(freeProductQuantity);}
		if (offerDiscountType!=null){details.offerDiscountType =Integer.parseInt(offerDiscountType);}
		if (offerDiscountValue!=null){details.offerDiscountValue =Integer.parseInt(offerDiscountValue);}
		if (offerProductQuantity!=null){details.offerProductQuantity =Integer.parseInt(offerProductQuantity);}
		if (offerID!=null){details.offerId = Integer.parseInt(offerID);}
		if (discountDetailsType!=null){details.DiscountDetailsType = Integer.parseInt(discountDetailsType);}
			System.out.println(details.getString());
		new CreateApproavedProduct();
		CreateApproavedProduct.offerDetails(details.getString());
	}	
}