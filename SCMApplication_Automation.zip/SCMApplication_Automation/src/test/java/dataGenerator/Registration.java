package dataGenerator;
import org.testng.annotations.Test;
import dataGenerator.*;

public class Registration {
	public void registration(String mobileNumber) throws Exception{
		RegistrationDetails details = new RegistrationDetails();
		details.RetailerNumber = mobileNumber;
		System.out.println(details.getString());
		new CreateApproavedProduct();
		CreateApproavedProduct.retailerDetails(details.getString());
	}	
}