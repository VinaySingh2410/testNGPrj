package dataGenerator;

import java.sql.SQLException;

public class productDetails {

	
	public String SellerName = "New Seller";
	public String BrandName = "Category";
	public String IsApproved = "1";
	public String Status = "1";
	public String ProductName = "New Product";
	public String packOf = "15";
	public String DiscountID = "0";
	public String isFreeProduct = "N";
	public String taxType = "VAT";
	public double percentage = 2;
	public double serviceFee = 0;
	public double MRP = 2420;
	public double dealerPrice = 2200;
	public double dealerMargin = 10;
	public int jitQty = 200;
	public int fpoQty = 0;//100;
	public int rtoQty = 0;//300;
	public int parentCategoryID = 428;
	public String masterIDToCreate="No";
	public int categoryID = 387;
	
	public String getString()
	{
		
		String str = "Seller Name=" + SellerName
				+",Brand Name=" + BrandName		
				+",Product Name=" + ProductName
				+",Is Free Product=" + isFreeProduct
				+",Packof=" + packOf
				+",Tax Type=" + taxType
				+",Is Free Product=" + isFreeProduct
				+",Tax Type=" + taxType
				+",Percentage=" + (int)percentage
				+",Service Fee=" + (int)serviceFee
				+",MRP=" +(int)MRP
				+",Dealer Price=" + (int)dealerPrice
				+",Dealer Margin=" + (int)dealerMargin
				+",JITQty=" + jitQty
				+",FPOQty=" + fpoQty
				+",RTOQty=" + rtoQty
				+",Category id=" + categoryID
				+",master ID="+masterIDToCreate
				+",Parent Categories=" + parentCategoryID;
		
		//return str;
		
		
//		String str =  "Seller Name,Brand Name,Is Approved,Status,Product Name,Packof,Discount Id,Is Free Product,Tax Type,Percentage,Service Fee,MRP,Dealer Price,Dealer Margin,JITQty,FPOQty,RTOQty,Category id,Parent Categories"
//		 		+""+SellerName+","+BrandName+","+IsApproved+","+Status+","+ProductName+","+packOf+","+DiscountID+","+isFreeProduct+","+taxType+","+percentage+","+serviceFess+","+MRP+","+dealerPrice+","+dealerMargin+","+jitQty+","+fpoQty+","+rtoQty+",387,"+categoryID+","+parentCategoryID+"";		
		
//		String str =  "Seller Name,Brand Name,Is Approved,Status,Product Name,Packof,Discount Id,Is Free Product,Tax Type,Percentage,Service Fee,MRP,Dealer Price,Dealer Margin,JITQty,FPOQty,RTOQty,Category id,Parent Categories@JBL@"
// 		+""+SellerName+","+BrandName+","+IsApproved+","+Status+","+ProductName+","+packOf+","+DiscountID+","+isFreeProduct+","+taxType+","+percentage+","+serviceFess+","+MRP+","+dealerPrice+","+dealerMargin+","+jitQty+","+fpoQty+","+rtoQty+",387,"+categoryID+","+parentCategoryID+"+@JBL@";		
		return str;
	}
//	
}
