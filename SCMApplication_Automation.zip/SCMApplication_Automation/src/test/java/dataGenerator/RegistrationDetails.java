package dataGenerator;

public class RegistrationDetails {	
	public String RetailerNumber="1234567890";
	public int stateId=21;//10;//21;
	public int cityId=569;//418;//569
	public int pincodeId=82149;//154835;//82149
	
	public String getString(){
		String str = "Retailer Number=" + RetailerNumber
				+",Retailer State Id=" + stateId
				+",Retailer City Id=" + cityId
				+",Retailer Pincode Id=" + pincodeId;
		
		return str;
	}
	
}
