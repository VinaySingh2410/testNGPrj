package dataGenerator;

public class OfferDetails {	
	

	/*************
	 ----------- Abbreviation used in offer Engine -----------	
	
	***** Definition of Offer Id		
		
		ID				Name	
		1				Volume Based	
		2				Value Based	
		
 	***** Definition of Offer Discount Type		
	
		ID				Name	
		1				flat amount	
		2				flat percentage	
		3				free SKU	
		
	***** Definition of Discount Value		
		
		Offer Discount type			Value				Examples
		1							1000				Rs.1000  off
		2							10					10% off
		3							it is always 0	
		
 	***** Definition of Free Product Quantity
 			
		Offer Id					Packof 				Example
		1							1					Buy 1 pack of some product…
		2							10000				Buy Rs.10000 worth products…
		
	 ***** Definition of Offer Product Quantity		
	
		Offer Discount type			Value				Example
		1							NA					NA
		2							NA					NA
		3							1					Get 1 pack of some product free…


	**************/
	
	public String SellerName = "TestSeller_9000"; 	//required 
	public String brandName = "Category";
	public String productName = "LG Led Monitor 3 _810956";
	public int offerId = 1;
	public String freeProductName = "LG Led Monitor 3 _810956";
	public int freeProductQuantity = 1;
	public int offerDiscountType = 3;
	public int DiscountDetailsType = 2;
	public int offerDiscountValue = 10;
	public int offerProductQuantity = 1;
	
	
	
	public String getString(){
		String str = "Seller Name=" + SellerName
				+",Offer Brand Name=" + brandName
				+",Offer Product Name=" + productName
				+",Offer Id=" + offerId
				+",Free Product Name=" + freeProductName
				+",Free Product Quantity=" + freeProductQuantity
				+",Offer Discount Type=" + offerDiscountType
				+",Offer Discount Value=" + offerDiscountValue
				+",Discount Details Type=" + DiscountDetailsType
				+",Offer Product Quantity=" + offerProductQuantity;
		
		return str;
	}
	
}
