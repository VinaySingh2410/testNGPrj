package dataGenerator;



public class Seller
{
	public void createSeller(String sellerName, String stateID, String isCPO, String isITC, String cityID, String pincode) throws Exception{
		SellerDetails details = new SellerDetails();
		
		if (sellerName!=null){details.sellerName = sellerName;}
	    if (stateID!=null){details.stateId = Integer.parseInt(stateID);}
	    if (isCPO!=null){details.isCPO = isCPO;}
	    if (isITC!=null){details.isITC = isITC;}
	    if (cityID!=null){details.cityId = cityID;}
	    if (pincode!=null){details.pincodeId = pincode;}
	    
		new CreateApproavedProduct();
		CreateApproavedProduct.sellerDetails(details.getString());
	}
}