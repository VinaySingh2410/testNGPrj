package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	
	@FindBy(how = How.ID, using ="id_username") WebElement userName;
	@FindBy(how = How.ID, using ="id_password") WebElement password;
	@FindBy(how = How.XPATH, using = "//input[@value='Log in']") WebElement loginBtn;
	@FindBy(how = How.XPATH, using = "//a[@contains(.,'Logout ')") WebElement logoutLink;
	

	
	public boolean login(String user, String pass)
	{
		userName.sendKeys(user);
		password.sendKeys(pass);
		loginBtn.click();
		return true;
	}
public void logout()
{
	//myAccountLink.click();
	logoutLink.click();

}
}
