package pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import reusable.CommonMethods;

public class LMDPage {

	@FindBy(how = How.XPATH, using = "//a[@title='LMD']")
	WebElement link_LMD;
	@FindBy(how = How.XPATH, using = "//a[@title='Pending LMD']")
	WebElement link_PendingLMD;
	@FindBy(how = How.XPATH, using = "//a[@title='Pending For Dispatch']")
	WebElement link_PendingForDispatch;
	@FindBy(how = How.XPATH, using = "//a[@title='Complete LMD']")
	WebElement link_ProcessedLMD;
	@FindBy(how = How.ID, using = "picklist_no")
	WebElement txtBox_PicklistNo;
	@FindBy(how = How.ID, using = "search_button")
	WebElement btn_SearchBtn;
	@FindBy(how = How.ID, using = "order_table")
	WebElement table_Order;
	@FindBy(how = How.XPATH, using = "//a[@title='JBL Warehouse Management']")
	WebElement header_JBLWareHouseMgmt;
	@FindBy(how = How.XPATH, using = "//a[@href='/wms/process/agn/']")
	WebElement header_ProcessAGN;
	@FindBy(how = How.ID, using = "lmd_list")
	WebElement list_LMD;
	// @FindBy(how = How.ID, using = "buttonsubmit") WebElement btn_Submit;
	@FindBy(how = How.CLASS_NAME, using = "btn_lmd_details")
	WebElement LMD_Glymph;
	@FindBy(how = How.ID, using = "lsp")
	WebElement picklist_ServiceProvider;
	@FindBy(how = How.ID, using = "nob")
	WebElement txtBox_NoOfBox;
	@FindBy(how = How.ID, using = "weight")
	WebElement txtBox_Weight;
	@FindBy(how = How.ID, using = "submit")
	WebElement btn_Submit;
	@FindBy(how = How.ID, using = "dispatch")
	WebElement btn_Dispatch;
	@FindBy(how = How.ID, using = "invoice_no")
	WebElement txtBox_InvoiceNo;
	@FindBy(how = How.XPATH, using = "//button[@title='Search']")
	WebElement searchButton;
	@FindBy(how = How.XPATH, using = "//*[@id='delhivery_table']/tbody/tr/td[10]/select")
	WebElement statusPicklist;
	@FindBy(how = How.ID, using = "order_lmd_submit")
	WebElement btn_Update;
	@FindBy(how = How.ID, using = "rto_dt")
	WebElement txtBox_RTODate;
	@FindBy(how = How.XPATH, using = "//*[@id='parent_div']/h2")
	WebElement pageHeaderTxt;
	@FindBy(how = How.XPATH, using = "//div[@class='dataTables_scrollBody']")
	WebElement dataTables_scrollBody;
	@FindBy(how = How.ID, using = "order_table")
	WebElement orderTable;

	@FindBy(how = How.LINK_TEXT, using = "Sales Return Received")
	WebElement salesReturnRecievedTab;
	@FindBy(how = How.LINK_TEXT, using = "Sales Return Inbound")
	WebElement salesReturnInboundTab;
	@FindBy(how = How.CLASS_NAME, using = "btn_product_details")
	WebElement AGN_Glymph;
	@FindBy(how = How.XPATH, using = "//button[@value='Create AGN']")
	WebElement btn_CreateAGN;

	@FindBy(how = How.XPATH, using = "//a[@title='GRN']")
	WebElement link_GRN;
	@FindBy(how = How.XPATH, using = "//button[contains(.,'UPDATE GRN DETAILS')]")
	WebElement btn_UpdateGRN;
	@FindBy(how = How.XPATH, using = "//button[contains(.,'Bin Location')]")
	WebElement btn_BinLocation;
	@FindBy(how = How.ID, using = "bin_location")
	WebElement txtBox_BinLocation;
	@FindBy(how = How.ID, using = "quantity")
	WebElement txtBox_Quantity;
	@FindBy(how = How.XPATH, using = "//input[@value='save']")
	WebElement btn_Save;

	WebDriver driver;
	boolean check = false;
	String actual, expected;
	static final Logger logger = Logger.getLogger(CommonMethods.class.getName());

	public void navigateToSalesReturnInboundTab() throws Exception {
		wait_for_object(header_JBLWareHouseMgmt);
		header_JBLWareHouseMgmt.click();
		//Thread.sleep(1000);
		wait_for_object(header_ProcessAGN);
		header_ProcessAGN.click();
		//Thread.sleep(2000);
		wait_for_object(salesReturnInboundTab);
		salesReturnInboundTab.click();
	}

	public void processSalesReturnInbound(String invoiceNumber) throws Exception {
		wait_for_object(txtBox_InvoiceNo);
		txtBox_InvoiceNo.sendKeys(invoiceNumber);
		searchButton.click();
		Thread.sleep(1000);
		wait_for_object(AGN_Glymph);
		AGN_Glymph.click();
		//Thread.sleep(500);
		wait_for_object(btn_UpdateGRN);
		btn_UpdateGRN.click();
		//Thread.sleep(2000);
	}

	public void processBinLocation(String binLocation) throws Exception {
		String quantity = "1";//"100";
		wait_for_object(btn_BinLocation);
		btn_BinLocation.click();
		wait_for_object(txtBox_BinLocation);
		txtBox_BinLocation.sendKeys(binLocation);
		txtBox_BinLocation.sendKeys(Keys.ENTER);
		txtBox_Quantity.sendKeys(quantity);
		btn_Save.click();
		//Thread.sleep(1000);
	}

	public void processSalesReturnRecived(String invoiceNumber) throws Exception {
		wait_for_object(txtBox_InvoiceNo);
		txtBox_InvoiceNo.sendKeys(invoiceNumber);
		searchButton.click();
		Thread.sleep(1000);
		wait_for_object(AGN_Glymph);
		AGN_Glymph.click();
		//Thread.sleep(2000);
		wait_for_object(btn_CreateAGN);
		btn_CreateAGN.click();
		//Thread.sleep(2000);
	}

	public void navigateToSalesReturnRecieved() throws Exception {
		wait_for_object(header_JBLWareHouseMgmt);
		header_JBLWareHouseMgmt.click();
		//Thread.sleep(1000);
		wait_for_object(header_ProcessAGN);
		header_ProcessAGN.click();
		//Thread.sleep(2000);
		wait_for_object(salesReturnRecievedTab);
		salesReturnRecievedTab.click();
	}

	public void processLMDTracker(String invoiceNumber) throws Exception {
		wait_for_object(pageHeaderTxt);
		pageHeaderTxt.click();
		pageHeaderTxt.sendKeys(Keys.HOME);
		txtBox_InvoiceNo.sendKeys(invoiceNumber);
		searchButton.click();
		Thread.sleep(3000);

		pageHeaderTxt.click();
		pageHeaderTxt.sendKeys(Keys.END);
		Thread.sleep(200);
		dataTables_scrollBody.click();
		for (int i = 0; i < 10; i++) {
			dataTables_scrollBody.sendKeys(Keys.ARROW_RIGHT);
		}
		Select picklistStatus = new Select(statusPicklist);
		picklistStatus.selectByVisibleText("RTO");
		Thread.sleep(200);
		txtBox_RTODate.click();
		txtBox_RTODate.sendKeys(Keys.ENTER);
		btn_Update.click();
	}

	public void processPicklistLMDDetails(String picklistNumber) throws Exception {
		navigatesToPendingLMPage();
		searchForPicklist(picklistNumber);
		wait_for_object(LMD_Glymph);
		LMD_Glymph.click();
		//Thread.sleep(2000);
		wait_for_object(picklist_ServiceProvider);
		Select serviceProvidePicklist = new Select(picklist_ServiceProvider);
		serviceProvidePicklist.selectByVisibleText("Just Buy Live");
		Thread.sleep(500);
		wait_for_object(txtBox_NoOfBox);
		txtBox_NoOfBox.sendKeys("5");
		txtBox_Weight.sendKeys("10");
		btn_Submit.click();
		//Thread.sleep(3000);

	}

	public void processPendingDispatch(String picklistNumber) throws Exception {
		navigatesToPendingLMPage();
		wait_for_object(link_PendingForDispatch);
		link_PendingForDispatch.click();
		searchForPicklist(picklistNumber);
		wait_for_object(btn_Dispatch);
		btn_Dispatch.click();
	}

	public void ClickOnProcessedLMDTab() throws Exception {
		navigatesToPendingLMPage();
		wait_for_object(link_ProcessedLMD);
		link_ProcessedLMD.click();

	}

	public boolean navigatesToPendingLMPage() throws Exception {
		wait_for_object(header_JBLWareHouseMgmt);
		header_JBLWareHouseMgmt.click();
		//Thread.sleep(1000);
		wait_for_object(header_ProcessAGN);
		header_ProcessAGN.click();
		wait_for_object(link_LMD);
		link_LMD.click();
		wait_for_object(link_PendingLMD);
		link_PendingLMD.click();
		wait_for_object(list_LMD);
		String data = list_LMD.getText();
		boolean chkValue = data.contains("Pending LMD");
		return chkValue;
	}

	public boolean searchForPicklist(String picklistNumber) throws Exception {
		wait_for_object(txtBox_PicklistNo);
		txtBox_PicklistNo.sendKeys(picklistNumber);
		btn_SearchBtn.click();
		Thread.sleep(1000);
		wait_for_object(table_Order);
		String data = table_Order.getText();
		boolean chkValue = data.contains(picklistNumber);
		return chkValue;
	}

	public void clickOnPicklist(String picklistNumber) throws InterruptedException {
		WebElement picklistLink = table_Order.findElement(By.linkText(picklistNumber));
		picklistLink.click();
		Thread.sleep(3000);
		Assert.assertEquals(driver.findElement(By.className("modal-dialog")).isDisplayed(), true);
	}

	public void enterValueinPickedQuantityPicklist(String productID, String qty) {
		WebElement txtBox_PickedQty = driver.findElement(By.xpath("//input[@data-prod_num='" + productID + "']"));
		txtBox_PickedQty.sendKeys(qty);
	}

	public void clickOnSubmitButton() throws Exception {
		wait_for_object(btn_Submit);
		btn_Submit.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}

	public void processPicklist(String picklistNumber, String productID, String qty) throws Exception {
		navigatesToPendingLMPage();
		searchForPicklist(picklistNumber);
		clickOnPicklist(picklistNumber);
		enterValueinPickedQuantityPicklist(productID, qty);
		clickOnSubmitButton();
	}
	
	   public boolean wait_for_object(WebElement obj) throws Exception {
			int timeout = 60000;//defaultTimeout;
		    int pollInterval = 500;//defaultPollInterval;

		    long start = System.currentTimeMillis();//aqDateTime.Now();
		    long elapsed = System.currentTimeMillis() - start;
		    while (elapsed <= timeout)
		    {
		        if (pollInterval > 0) Thread.sleep(pollInterval);;
		        if (obj.isDisplayed() && obj.isEnabled()) return true;

		        elapsed = System.currentTimeMillis() - start;
		    }
		    logger.info("Object fails to load in time bound");
		    return false;
		  }
}
