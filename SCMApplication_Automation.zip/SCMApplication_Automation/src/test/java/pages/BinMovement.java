package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BinMovement {
	@FindBy(how = How.XPATH, using = "//a[@title='JBL Warehouse Management'][@data-toggle='dropdown']") WebElement header_JBLWareHouseMgmt;
	@FindBy(how = How.XPATH, using = "//a[@title='BIN MOVEMENT PUTAWAYLIST']") WebElement binMovemen_Option;
	@FindBy(how = How.XPATH, using = "//button[@value='Create']") WebElement binMovemenCreate_Btn;
	@FindBy(how = How.XPATH, using = "//button[@title='Internal Stock Transfer'][@data-id='stn_type']") WebElement picklist_SelectType;
	@FindBy(how = How.XPATH, using = "//button[@title='Select'][@data-id='warehouse_id']") WebElement picklist_WareHouseID;
	@FindBy(how = How.XPATH, using = "//input[@class='input-block-level form-control'][@type='text']") WebElement input_WareHouseID;
	//@FindBy(how = How.XPATH, using = "//button[@title='Select'][@data-id='warehouse_id']") WebElement picklist_WareHouseID;
}
