package pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import CommonHooks.Hooks;
import dataGenerator.PropertyFileReader;
import reusable.CommonMethods;
import reusable.SCMPropertyFileReader;

public class OrderPage {

	@FindBy(how = How.XPATH, using = "//a[@title='Order History']") WebElement orderHistoryTab;
	@FindBy(how = How.ID, using = "searchi") WebElement searchTextBox;
	@FindBy(how = How.ID, using = "searching") WebElement searchBtn;
	@FindBy(how = How.CLASS_NAME, using = "orderTable") WebElement resulTable;
	@FindBy(how = How.ID, using = "viewdetails") WebElement viewTableBtn;
	@FindBy(how = How.ID, using = "order_info_block") WebElement orderInfoTable;
	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "0000000174") WebElement POLink;


	@FindBy(how = How.XPATH, using = "//a[@title='LMD']") WebElement link_LMD;
	@FindBy(how = How.XPATH, using = "//a[@title='Pending LMD']") WebElement link_PendingLMD;
	@FindBy(how = How.XPATH, using = "//a[@title='Pending For Dispatch']") WebElement link_PendingForDispatch;
	@FindBy(how = How.XPATH, using = "//a[@title='Processed LMD']") WebElement link_ProcessedLMD;
	@FindBy(how = How.ID, using = "picklist_no") WebElement txtBox_PicklistNo;
	@FindBy(how = How.ID, using = "po_no") WebElement txtBox_PONo;
	@FindBy(how = How.ID, using = "search_button") WebElement btn_SearchBtn;
	@FindBy(how = How.ID, using = "order_table") WebElement table_Order;
	@FindBy(how = How.XPATH, using = "//a[@title='JBL Warehouse Management'][@data-toggle='dropdown']") WebElement header_JBLWareHouseMgmt;
	@FindBy(how = How.XPATH, using = "//a[@title='JBL Warehouse Management'][@href='/wms/process/agn/']") WebElement header_ProcessAGN;
	@FindBy(how = How.ID, using = "lmd_list") WebElement list_LMD;
	@FindBy(how = How.ID, using = "buttonsubmit") WebElement btn_Submit;
	@FindBy(how = How.ID, using = "picklist_product_list") WebElement picklist_productListTable;


	@FindBy(how = How.XPATH, using = "//a[@title='Service Provider']") WebElement link_ServiceProvider;
	@FindBy(how = How.LINK_TEXT, using = "//a[@title='Fulfillment']") WebElement link_Fulfillment;
	@FindBy(how = How.XPATH, using = "//a[@title='Create FPO']") WebElement link_CreateFPO;
	@FindBy(how = How.XPATH, using = "//select[@name='retailer']") WebElement picklist_sellerName;
	@FindBy(how = How.XPATH, using = "//select[@name='seller_warehouse']") WebElement picklist_warehouse;
	@FindBy(how = How.XPATH, using = "//select[@name='fc_city']") WebElement picklist_fcCity;
	@FindBy(how = How.XPATH, using = "//select[@name='product']") WebElement picklist_Product;
	@FindBy(how = How.XPATH, using = "//input[@name='quantity']") WebElement textBox_Quantity;
	@FindBy(how = How.XPATH, using = "//button[@type='submit']") WebElement btn_GenerateFPO;
	@FindBy(how = How.XPATH, using = "//a[@title='View FPO']") WebElement link_ViewFPO;
	@FindBy(how = How.ID, using = "Search") WebElement textBox_Search;
	@FindBy(how = How.CLASS_NAME, using = "btn_product_details") WebElement AGN_Glymph;
	@FindBy(how = How.XPATH, using = "//button[@value='Create AGN']") WebElement btn_CreateAGN;

	@FindBy(how = How.XPATH, using = "//a[@title='GRN']") WebElement link_GRN;
	@FindBy(how = How.XPATH, using = "//button[contains(.,'UPDATE GRN DETAILS')]") WebElement btn_UpdateGRN;
	@FindBy(how = How.XPATH, using = "//button[contains(.,'Bin Location')]") WebElement btn_BinLocation;
	@FindBy(how = How.ID, using = "bin_location") WebElement txtBox_BinLocation;
	@FindBy(how = How.ID, using = "quantity") WebElement txtBox_Quantity;
	@FindBy(how = How.XPATH, using = "//input[@value='save']") WebElement btn_Save;
	@FindBy(how = How.XPATH, using = "//label[@title='ILP Information']") WebElement label_ILPInformation;

	WebDriver driver;
	static final Logger logger = Logger.getLogger(CommonMethods.class.getName());
	public OrderPage (){
		driver = Hooks.driver;
	}
	
	public void generateFPO(String productName, String sellername, String quantity) throws Exception
	{
		String fpoPicklist_SellerName = sellername;
		//String fpoWarehouse_PicklistName = "sellerwarehousemock577 (MAHARASHTRA,Thane)";
		String fpoPicklistCityName = "JBL01 - Thane";
		

		link_CreateFPO.click();
		//Thread.sleep(1000);
		wait_for_object(picklist_sellerName);
		Select sellernamePicklist =new Select(picklist_sellerName);
		sellernamePicklist.selectByVisibleText(fpoPicklist_SellerName);
		Thread.sleep(2000);
		//wait_for_object(picklist_sellerName);
		//selectOptionFromPicklist(picklist_sellerName, fpoPicklist_SellerName);
		selectOptionFromPicklist(picklist_warehouse, fpoPicklist_SellerName);
		selectOptionFromPicklist(picklist_fcCity, fpoPicklistCityName);
		selectOptionFromPicklist(picklist_Product, productName);
		textBox_Quantity.sendKeys(quantity);

		btn_GenerateFPO.click();
		Thread.sleep(2000);

		//Runtime.getRuntime().exec("C:\\Users\\vinay.damco\\Desktop\\AutoIT\\fileUpload.exe");

	}

	public void clickOnILPProcessingTab()
	{
		label_ILPInformation.click();
		
	}
	
	public void selectOptionFromPicklist(WebElement picklistName, String itemName)
	{
		Select sel = new Select(picklistName);

		List <WebElement> elementCount = sel.getOptions();
		int iSize = elementCount.size();
		for(int i =0; i<iSize ; i++){
			String sValue = elementCount.get(i).getText();
			if (sValue.contains(itemName))
				sel.selectByVisibleText(sValue);

		}
	}

	public void viewFPO() throws InterruptedException
	{
		link_ViewFPO.click();
		Thread.sleep(1000);
	}

	public void clickILPInformationLabel()
	{
		label_ILPInformation.click();
	}

	public void processAGN(String FPONumber) throws Exception
	{

		header_JBLWareHouseMgmt.click();
		//Thread.sleep(1000);
		wait_for_object(header_ProcessAGN);
		header_ProcessAGN.click();
		wait_for_object(textBox_Search);
		//Thread.sleep(1000);
		wait_for_object(textBox_Search);
		textBox_Search.sendKeys(FPONumber);
		btn_SearchBtn.click();
		wait_for_object(AGN_Glymph);
		//Thread.sleep(2000);
		AGN_Glymph.click();
		//Thread.sleep(2000);
		wait_for_object(btn_CreateAGN);
		btn_CreateAGN.click();
		//Thread.sleep(2000);
	}

	public void processGRN(String FPONumber) throws Exception
	{
		link_GRN.click();
		wait_for_object(textBox_Search);
		textBox_Search.sendKeys(FPONumber);
		btn_SearchBtn.click();
		//Thread.sleep(2000);
		wait_for_object(AGN_Glymph);
		AGN_Glymph.click();
		//Thread.sleep(500);
		wait_for_object(btn_UpdateGRN);
		btn_UpdateGRN.click();
		//Thread.sleep(2000);

	}
	public void processBinLocation(String quantity, String typeOfOrder) throws Exception
	{
//		String binLocation;
//		if (typeOfOrder=="PO"){binLocation = "j10";}
//		else{binLocation= "F100";}
//		wait_for_object(btn_BinLocation);
//		btn_BinLocation.click();
//		wait_for_object(txtBox_BinLocation);
//		txtBox_BinLocation.sendKeys(binLocation);
//		txtBox_BinLocation.sendKeys(Keys.ENTER);
//		txtBox_Quantity.sendKeys(quantity);
//		btn_Save.click();
//		//Thread.sleep(3000);
		
		
		
		WebElement orderTable = driver.findElement(By.id("grn_pro"));
		List<WebElement> rows = orderTable.findElements(By.xpath("//table[@id='grn_pro']//tbody//tr"));
		for(int i=1;i<=rows.size();i++)
		{
			WebElement rrow = driver.findElement(By.xpath("//table[@id='grn_pro']//tbody//tr["+i+"]"));
			String pname = rrow.findElement(By.xpath("//tr["+i+"]//td[@class='td_alignment product_name']")).getText();
			System.out.println(pname);
			String acceptedQty = rrow.findElement(By.xpath("//tr["+i+"]//td[@class='td_alignment']")).getText();
			System.out.println(acceptedQty+"  =========================");
			Thread.sleep(5000);
			rrow.findElement(By.xpath("//tr["+i+"]//td[10]//button")).click();
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			wait_for_object(driver.findElement(By.id("bin_location")));
			if(typeOfOrder.equalsIgnoreCase("po"))
			{
				driver.findElement(By.id("bin_location")).sendKeys("j");
			}
			else
			{
				driver.findElement(By.id("bin_location")).sendKeys("f");
			}
			Thread.sleep(5000);
			WebElement binlistutil = driver.findElement(By.className("binlistul"));
			List<WebElement> binlocations = binlistutil.findElements(By.tagName("li"));
			binlocations.get(1).click();
			driver.findElement(By.id("quantity")).sendKeys(acceptedQty);
			driver.findElement(By.xpath(".//*[@class='btn btn-primary'][2]")).click();
			handleAlertPopUP("Bin location is set");
			Thread.sleep(2000);
			driver.findElement(By.id("modal-close")).click();
		}

	}

	public void verifyProductUnderPicklistProductTable(String productName, String qty)
	{

		String data = picklist_productListTable.getText();
		boolean chkProduct = data.contains(productName);
		boolean chkQty = data.contains(qty);
		Assert.assertEquals(chkProduct,true);
		Assert.assertEquals(chkQty,true);
	}
	public boolean verifyOrderNoInOrderInfoTable(String orderNumber) throws Exception
	{
		//Thread.sleep(2000);
		wait_for_object(orderInfoTable);
		String data = orderInfoTable.getText();
		boolean chkValue = data.contains(orderNumber);
		logger.info("Verify if order number is displaying in the SCm application or not.");
		return chkValue;	
	}
	public void clickOnPOLink() throws InterruptedException
	{
		POLink.click();
		//Thread.sleep(2000);
	}
	public void searchOrder(String orderNumber)
	{
		navigateSearchOrder();
		searchOrederID(orderNumber);
	}
	public void clickViewDetailBtn() throws InterruptedException
	{
		viewTableBtn.click();
		//Thread.sleep(3000);
	}
	public void navigateSearchOrder()
	{
		orderHistoryTab.click();
		logger.info("Clicked on the Order History Tab.");
	}
	public void searchOrederID(String orderNumber)
	{
		searchTextBox.sendKeys(orderNumber);
		logger.info("Enter the order number in search text box.");
		searchBtn.click();
	}
	public boolean verifyOrderInResultList(String orderNumber) throws Exception
	{
		//Thread.sleep(5000);
		wait_for_object(resulTable);
		String data = resulTable.getText();
		boolean chkValue = data.contains(orderNumber);
		return chkValue;
	}

	public boolean navigatesToPendingLMPage()throws Exception
	{
		Thread.sleep(5000);
		wait_for_object(header_JBLWareHouseMgmt);
		header_JBLWareHouseMgmt.click();
		Thread.sleep(1000);
//		WebElement dropDown = driver.findElement(By.className("dropdown-menu"));
//		WebElement warehouseMgmt_Header =dropDown.findElement(By.xpath("//a[@title='JBL Warehouse Management'][@href='/wms/process/agn/']"));
		wait_for_object(header_ProcessAGN);
		header_ProcessAGN.click();
		//warehouseMgmt_Header.click();
		//Thread.sleep(1000);
		wait_for_object(link_LMD);
		link_LMD.click();
		link_PendingLMD.click();
		String data = list_LMD.getText();
		boolean chkValue = data.contains("Pending LMD");
		return chkValue;

	}
	public boolean searchForPicklist(String picklistNumber) throws Exception
	{
		txtBox_PicklistNo.clear();
		txtBox_PicklistNo.sendKeys(picklistNumber);
		btn_SearchBtn.click();
		//Thread.sleep(2000);
		wait_for_object(table_Order);
		String data = table_Order.getText();
		boolean chkValue = data.contains(picklistNumber);
		return chkValue;
	}
	//	
	public boolean searchForPO(String poNumber) throws Exception
	{
		txtBox_PicklistNo.clear();
		txtBox_PONo.sendKeys(poNumber);
		btn_SearchBtn.click();
		//Thread.sleep(2000);
		wait_for_object(table_Order);
		String data = table_Order.getText();
		boolean chkValue = data.contains(poNumber);
		return chkValue;
	}
	public void clickOnPicklist(String picklistNumber) throws InterruptedException
	{
		WebElement picklistLink = table_Order.findElement(By.linkText(picklistNumber));
		picklistLink.click();
		//Thread.sleep(3000);
	}

	public void clickOnSubmitButton() throws InterruptedException
	{
		btn_Submit.click();
		//Thread.sleep(1000);
	}

	public boolean searchForPicklistRetailerInvoice(String picklistNumber, String retailerInvoice) throws Exception
	{
		searchForPicklist(picklistNumber);

		String data = table_Order.getText();
		boolean chkPicklist = data.contains(picklistNumber);
		boolean chkRetailer = data.contains(retailerInvoice);
		return chkPicklist && chkRetailer;
	}
	public void processPicklist(String picklistNumber) throws Exception
	{
		navigatesToPendingLMPage();
		searchForPicklist(picklistNumber);
		clickOnPicklist(picklistNumber);
	}
	public ArrayList<HashMap<String, WebElement>> getDataFromTable(WebElement tableElement)
	{
		// create empty table object and iterate through all rows of the found table element
		ArrayList<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));
		// get column names of table from table headers
		ArrayList<String> columnNames = new ArrayList<String>();
		ArrayList<WebElement> headerElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//th"));
		for (WebElement headerElement: headerElements) {
		     System.out.println(headerElement.getText());
			columnNames.add(headerElement.getText());
		}

		// iterate through all rows and add their content to table array
		for (WebElement rowElement: rowElements) {
		  HashMap<String, WebElement> row = new HashMap<String, WebElement>();
		  
		  // add table cells to current row
		  int columnIndex = 0;
		  ArrayList<WebElement> cellElements = (ArrayList<WebElement>) rowElement.findElements(By.xpath(".//td"));
		  for (WebElement cellElement: cellElements) {
		    row.put(columnNames.get(columnIndex), cellElement);
		    columnIndex++;
		  }
		  
		  userTable.add(row);
		}
		return userTable;
	}
	
	public void verifyRetailerInvoiceForPicklist(String expectedPicklistName,String expectedInvoiceNumber) throws Exception{
		navigatesToPendingLMPage();
		searchForPicklist(expectedPicklistName);
		//Thread.sleep(3000);
		wait_for_object(table_Order);
		Thread.sleep(2000);
		ArrayList<HashMap<String, WebElement>> tableData = getDataFromTable(table_Order);
		Assert.assertEquals(tableData.get(1).get("PICKLIST NO.").getText(),expectedPicklistName);
		Assert.assertEquals(tableData.get(1).get("RETAILER INVOICE").getText(),expectedInvoiceNumber);
	}
	
	public void verifyInvoiceStatus(String expectedPicklistName, String expectedStatus) throws Exception{
		searchForPicklist(expectedPicklistName);
		ArrayList<HashMap<String, WebElement>> tableData = getDataFromTable(table_Order);
		Assert.assertEquals(tableData.get(1).get("PICKLIST NO.").getText(),expectedPicklistName);
		Assert.assertEquals(tableData.get(1).get("LMD STATUS").getText(),expectedStatus);
	}
	public int getIndexOfExpectedRow(ArrayList<HashMap<String, WebElement>> tableData ,String expectedColumnName, String ColumnValue){
		for (int i=0;i<tableData.size();i++)
		{
			if (tableData.get(i).get(expectedColumnName).getText()==ColumnValue)
				return i;
		}
		return 0;
	}
	public void handleAlertPopUP(String popUpMessage)
	{
		WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(PropertyFileReader.GetValue("waitTime")));
		wait.until(ExpectedConditions.alertIsPresent());
		if(driver.switchTo().alert().getText().equalsIgnoreCase(popUpMessage)){
		   driver.switchTo().alert().accept();
		   logger.info(popUpMessage +" message is dislaying in pop widnow.");
		}
		else{
			String alertText = driver.switchTo().alert().getText();
			logger.error(alertText+" message is displaying in the alert window istead of "+popUpMessage);
			//driver.switchTo().alert().accept();
			Assert.assertEquals(driver.switchTo().alert().getText(), popUpMessage, popUpMessage+"messgae is displaying in alert window");
		}
	}
	
	   public boolean wait_for_object(WebElement obj) throws Exception {
			int timeout = 60000;//defaultTimeout;
		    int pollInterval = 500;//defaultPollInterval;

		    long start = System.currentTimeMillis();//aqDateTime.Now();
		    long elapsed = System.currentTimeMillis() - start;
		    while (elapsed <= timeout)
		    {
		        if (pollInterval > 0) Thread.sleep(pollInterval);;
		        if (obj.isDisplayed() && obj.isEnabled()) return true;

		        elapsed = System.currentTimeMillis() - start;
		    }
		    logger.info("Object fails to load in time bound");
		    return false;
		  }
	
	@Test
	public void testTable() throws InterruptedException
	{
		WebDriver webDriver = new FirefoxDriver();
		webDriver.navigate().to("http://scbetanv3.justbuylive.in/wms/view_picklist_details/18859/");
		Thread.sleep(10000);
		webDriver.navigate().to("http://scbetanv3.justbuylive.in/wms/view_picklist_details/18859/");
		// simplified: find table which contains the keyword
		Thread.sleep(3000);
		WebElement tableElement = webDriver.findElement(By.xpath("//*[@id='picklist_product_list']"));
		ArrayList<HashMap<String, WebElement>> tableData = getDataFromTable(tableElement);
		WebElement table1 = tableData.get(1).get("Qty/Pcs");
	}


}
